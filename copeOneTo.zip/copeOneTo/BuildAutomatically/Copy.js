var fs   = require('fs')
var path = require('path')
var process = require("process");
// var map = require("./map");
var config = require("./Config");



var BuildType = process.argv[2];
var BuildCate = process.argv[3];
var Dist = config["Config" + BuildType]["Dist" + BuildCate];
var Dist2 = Dist + "/" + config["Config" + BuildType].Version;
var mySrc = config["Config" + BuildType].Src;
console.log("copy路径" + Dist);
console.log("copy路径" + Dist2);


var copyFile = function(srcPath, tarPath, cb) {
  var rs = fs.createReadStream(srcPath)
  rs.on('error', function(err) {
    if (err) {
      console.log('read error', srcPath)
    }
    cb && cb(err)
  })

  var ws = fs.createWriteStream(tarPath)
  ws.on('error', function(err) {
    if (err) {
      console.log('write error', tarPath)
    }
    cb && cb(err)
  })
  ws.on('close', function(ex) {
    cb && cb(ex)
  })

  rs.pipe(ws)
}
var copyFolder = function(srcDir, tarDir, cb, bool) {
    fs.readdir(srcDir, function(err, files) {
      var count = 0
      var checkEnd = function() {
        ++count == files.length && cb && cb()
      }
  
      if (err) {
        checkEnd()
        return
      }
  
      files.forEach(function(file) {
        if(file !== "res" && file !== "src" && bool){
            return;
        }

        var srcPath = path.join(srcDir, file)
        var tarPath = path.join(tarDir, file)
  
        fs.stat(srcPath, function(err, stats) {
          if (stats.isDirectory()) {
            console.log('mkdir', tarPath)
            fs.mkdir(tarPath, function(err) {
              if (err) {
                console.log(err)
                return
              }
  
              copyFolder(srcPath, tarPath, checkEnd)
            })
          } else {
             //子游戏不需要cocos2d-jsb.js
             copyFile(srcPath, tarPath, checkEnd)
            // if(!/cocos2d-jsb.\js$/.test(srcPath) && !/cocos2d-jsb.\jsc$/.test(srcPath)){
            //   copyFile(srcPath, tarPath, checkEnd)
            // };

          }
        })
      })
  
      //为空时直接回调
      files.length === 0 && cb && cb()
    })
  }
if( true ){
  var time = +new Date();
  fs.mkdir(Dist,function(err){
    console.log(+new Date() - time)
     if (err) {

         // return console.error(err);

     }
  });
}
setTimeout(()=>{
  fs.mkdir(Dist2,function(err){

     if (err) {

         // return console.error(err);

     }
     copyFolder(mySrc, Dist2, function(err) {
      if (err) {
    
        return
      }
    
      //continue
    },true)
  });
},100)

