var fs   = require('fs')
var path = require('path')
var process = require("process");
const config = require("./Config");
var BuildType = process.argv[2];
var BuildCate = process.argv[3];
var Dist = config["Config" + BuildType]["Dist" + BuildCate];
console.log("删除路径为" + Dist);


function deleteall( path ) {
	var files = [];
	if(fs.existsSync(path)) {
		files = fs.readdirSync(path);
		files.forEach(function(file, index) {
			var curPath = path + "/" + file;
			if(fs.statSync(curPath).isDirectory()) { // recurse
				deleteall(curPath);
			} else { // delete file
				fs.unlinkSync(curPath);
			}
		});
		fs.rmdirSync(path);
	}
}
deleteall( Dist );
