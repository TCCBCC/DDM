/**
 * 此模块用于热更新工程清单文件的生成
 */
var crypto = require('crypto');
var fs   = require('fs')
var path = require('path')
var process = require("process");
// var map = require("./map");

var config = require("./Config");


var BuildType = process.argv[2];
var BuildCate = process.argv[3];

var Dist = config["Config" + BuildType]["Dist" + BuildCate] + "/"+ config["Config" + BuildType].Version
console.log(Dist)




var manifest = {
    //服务器上资源文件存放路径（src，res的路径）
    packageUrl: config["Config" + BuildType]["IP" + BuildCate] + "/" +  config["Config" + BuildType].Platform + "/hall/" + config["Config" + BuildType].Version,
    //服务器上project.manifest路径
    remoteManifestUrl: config["Config" + BuildType]["IP" + BuildCate] + "/" +  config["Config" + BuildType].Platform + "/hall/" + config["Config" + BuildType].Version + '/project.manifest',
    //服务器上version.manifest路径
    remoteVersionUrl: config["Config" + BuildType]["IP" + BuildCate] + "/" +  config["Config" + BuildType].Platform + "/hall/" + config["Config" + BuildType].Version + '/version.manifest',
    version: config["Config" + BuildType].Version,
    assets: {},
    searchPaths: []
};

//生成的manifest文件存放目录
var dest = Dist;
console.log(manifest)
console.log("生成的manifest文件存放目录" + dest);
//项目构建后资源的目录
var src = config["Config" + BuildType].Src

/**
 * node version_generator.js -v 1.0.0 -u http://your-server-address/tutorial-hot-update/remote-assets/ -s native/package/ -d assets/
 */
// Parse arguments
var i = 2;
while ( i < process.argv.length) {
    var arg = process.argv[i];

    switch (arg) {
    case '--url' :
    case '-u' :
        var url = process.argv[i+1];
        manifest.packageUrl = url;
        manifest.remoteManifestUrl = url + 'project.manifest';
        manifest.remoteVersionUrl = url + 'version.manifest';
        i += 2;
        break;
    case '--version' :
    case '-v' :
        manifest.version = process.argv[i+1];
        i += 2;
        break;
    case '--src' :
    case '-s' :
        src = process.argv[i+1];
        i += 2;
        break;
    case '--dest' :
    case '-d' :
        dest = process.argv[i+1];
        i += 2;
        break;
    default :
        i++;
        break;
    }
}


function readDir (dir, obj) {
    var stat = fs.statSync(dir);
    if (!stat.isDirectory()) {
        return;
    }
    var subpaths = fs.readdirSync(dir), subpath, size, md5, compressed, relative;
    for (var i = 0; i < subpaths.length; ++i) {
        if (subpaths[i][0] === '.') {
            continue;
        }
        subpath = path.join(dir, subpaths[i]);
        stat = fs.statSync(subpath);
        if (stat.isDirectory()) {
            readDir(subpath, obj);
        }
        else if (stat.isFile()) {

            //子游戏不需要cocos2d-jsb.js
            // if(/cocos2d-jsb.\js$/.test(subpath) || /cocos2d-jsb.\jsc$/.test(subpath))continue;
            // Size in Bytes
            size = stat['size'];
            
            // md5 = crypto.createHash('md5').update(fs.readFileSync(subpath, 'binary')).digest('hex');

			md5 = crypto.createHash('md5').update(fs.readFileSync(subpath)).digest('hex');


            compressed = path.extname(subpath).toLowerCase() === '.zip';

            relative = path.relative(src, subpath);
            relative = relative.replace(/\\/g, '/');
            relative = encodeURI(relative);
            obj[relative] = {
                'size' : size,
                'md5' : md5
            };
            if (compressed) {
                obj[relative].compressed = true;
            }
        }
    }
}

var mkdirSync = function (path) {
    try {
        fs.mkdirSync(path);
    } catch(e) {
        if ( e.code != 'EEXIST' ) throw e;
    }
}

// Iterate res and src folder
readDir(path.join(src, 'src'), manifest.assets);
readDir(path.join(src, 'res'), manifest.assets);

var destManifest = path.join(dest, 'project.manifest');
var destVersion = path.join(dest, 'version.manifest');

// if(is_server){
//     var  destManifest2 = path.join(config.dest2,"project.manifest");
//     var  destVersion2 =  path.join(config.dest2,"version.manifest");
// }

mkdirSync(dest);

fs.writeFile(destManifest, JSON.stringify(manifest), (err) => {
  if (err) throw err;
  console.log('Manifest successfully generated');
});

// if(is_server){
//     fs.writeFile(destManifest2, JSON.stringify(manifest), (err) => {
//       if (err) throw err;
//       console.log('Manifest successfully generated');
//     });
// }


delete manifest.assets;
delete manifest.searchPaths;
fs.writeFile(destVersion, JSON.stringify(manifest), (err) => {
  if (err) throw err;
  console.log('Version successfully generated');
});

// if(is_server){
//     fs.writeFile(destVersion2, JSON.stringify(manifest), (err) => {
//       if (err) throw err;
//       console.log('Version successfully generated');
//     });
// }