
const ConfigFB = {
	Version:   '1.0.60', // 版本号
    IPZ:        "",    //热更新地址
    IPB:       "",     //备用热更新地址
    DistZ:      "C:/Users/kiven/Desktop/OnlineBuild/Z/hall",  // 输出目录
    DistB:      "C:/Users/kiven/Desktop/OnlineBuild/B/hall",  // 备用输出目录
    Src:       "D:/SWoker/HXHall/build/jsb-link", //项目构建后资源的目录
    Platform:  "android" // 平台
}
const ConfigHD = { // 灰度
	Version:   '1.0.50', // 版本号
    IPZ:        "",    //热更新地址
    IPB:       "",	 //备用热更新地址
    DistZ:      "C:/Users/kiven/Desktop/RelaseBuild/Z/hall",  // 输出目录
    DistB:      "C:/Users/kiven/Desktop/RelaseBuild/B/hall",  // 备用输出目录
    Src:       "D:/SWoker/HXHall/build/jsb-link", //项目构建后资源的目录
    Platform:  "Android" // 平台
}
const Config = {
	ConfigFB, ConfigHD
};

module.exports = Config;

