var api = module.exports = {};

//进入大厅
api.entry = function (requestData, cbRouter, cbFail) {
    var router = 'connector.entryHandler.entry';
    
    if( Global.myDisconnect ) requestData.reconnect = true;
    
    Global.NetworkManager.send(router, requestData, cbRouter || 'EntryHallResponse', cbFail);
};

// --------------------------------------------用户相关------------------------------------------
//查找玩家，获取玩家信息
api.searchRequest = function (uid, cbRouter) {
    var router = 'hall.userHandler.searchUserData';
    var requestData = {
        uid:uid
    };
    Global.NetworkManager.send(router, requestData, cbRouter || 'SearchResponse')
};
