var api = module.exports = {};
// 登录
api.login = function (params, cbSuccess, cbFail) {
    let route = "/login";
    Global.NetworkLogic.gameServerHttpRequest(route, 'POST', params, cbSuccess, cbFail);
};

api.getPhoneCode = function(params, cbSuccess, cbFail) {
    let route = "/getSMSCode";
    Global.NetworkLogic.gameServerHttpRequest(route, 'POST', params, cbSuccess, cbFail);
}
