var messageCallback = require('./MessageCallback');

var pomelo = window.pomelo;

var networkManager = module.exports = {};

networkManager.init = function (params,cb) {
    pomelo.init({
        host: params.host,
        port: params.port,
        log: true
    }, cb);
};

networkManager.disconnect = function () {
    pomelo.disconnect();
};

networkManager.request = function (route, msg, cbSuccess, cbFail) {
    if(CC_DEBUG) console.log('Send:' + route);
    if(CC_DEBUG) console.log(msg);
    pomelo.request(route, msg, function (data) {
        if(CC_DEBUG) console.log('Receive:' + (((typeof cbSuccess) === 'string')?cbSuccess:route),"x-------");
        if(CC_DEBUG) console.log(data);
        if(window.jsb){
                try{
                    if(CC_DEBUG) console.log(JSON.stringify(data),"x-------")
                }catch(e){

                }
            }

        if(CC_DEBUG) console.log("请求到的后台数据");
        if (data.code !== Global.Code.OK) {
            // Global.DialogManager.removeLoadingCircle();
            if(data.code === Global.Code.GAME_CENTER.ALREADY_IN_ROOM){ // 防止在其他游戏进入其他游戏
                Global.Player.roomId = data.msg.roomID;
                Global.Player.gameKind = data.msg.gameKind;
                let text = Global.Code[data.code];
                Global.DialogManager.showCommonDialog('PopDialog', text,function(){
                    Global.CCHelper.entrySubgame(data.msg);
                },true);
                return;
            }
            // if (!!cbFail && (typeof (cbFail) === 'function')){
            //     cbFail(data);
            //     return;
            // }
            if (!!Global.Code[data.code]) {
                if(data.code === 224) {
                    // cc.log()
                    Global.DialogManager.showCommonDialog("PopDialog", data.msg, function() {

                        
                    }, true); 
                } else {
                    Global.DialogManager.showCommonDialog("CommenTipDialog",Global.Code[data.code]);
                }
                
                if (!!cbFail && (typeof (cbFail) === 'function')){
                    cbFail(data);
                }
            } else {
                Global.DialogManager.showCommonDialog("CommenTipDialog",'游戏错误，错误码：' + data.code);
                if (!!cbFail && (typeof (cbFail) === 'function')){
                    cbFail(data);
                }
            }
        }else{
            if (!!cbSuccess){
                if (typeof(cbSuccess) === 'function') {
                    cbSuccess(data);
                }else{
                    messageCallback.emitMessage(cbSuccess, data);
                }
            }
        }
    });
};

networkManager.send = function (route, msg, cbRoute, cbFail) {
    if(CC_DEBUG) cc.log(msg)
    this.request(route, msg, cbRoute, cbFail);
};

networkManager.notify = function (route, msg){
    if(CC_DEBUG) console.log('Notify:' + route,"x-------");
    if(CC_DEBUG) console.log(msg);
    if(CC_DEBUG){
        if(window.jsb){
            try{
                console.log(JSON.stringify(msg),"x-------")
            }catch(e){}
        }
        
    } 
    if( Global.Player.canNotNotify ) return;
    pomelo.notify(route, msg);
};

networkManager.addReceiveListen = function (route, cbRoute) {
    cbRoute = cbRoute || route;
    let pushCallback = function (msg) {
        if(CC_DEBUG) console.log(msg);
        if (!!cbRoute){
            if(CC_DEBUG) console.log('push:' + cbRoute,"x-------");
            if(CC_DEBUG) console.log(msg);
            if(window.jsb){
                try{
                    if(CC_DEBUG) console.log(JSON.stringify(msg),"x-------")
                }catch(e){

                }
            }
            messageCallback.emitMessage(cbRoute, msg);
        }
    };
    pomelo.on(route, pushCallback);
    return pushCallback;
};

networkManager.removeListener = function (route, callback){
    pomelo.removeListener(route, callback);
};

networkManager.removeAllListeners = function (){
    pomelo.removeAllListeners();
};