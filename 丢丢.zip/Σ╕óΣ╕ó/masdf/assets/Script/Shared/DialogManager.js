var DialogManager = module.exports = {}; // 对话弹出层



DialogManager.removeTip = function() {
    if(CC_DEBUG) cc.log("删除tip");
}


DialogManager.addLoading = function() {
		if(CC_DEBUG) cc.log("longding....")

};

DialogManager.removeLoading = function() {
    let pNode = cc.find("Canvas") || cc.find("game")
    let node = pNode.getChildByName("LoadingDialog");
    if(node) node.destroy();
	if(CC_DEBUG) cc.log("删除loading....")
}

DialogManager.addPopDailogPrefab = function( PrefabUrl ) {
		 let prefabName = PrefabUrl.split('/')[1];
	     //  加载预制资源
	      cc.loader.loadRes( PrefabUrl, function(errorMessage,loadedResource){
	          // 检查资源加载
	          if( errorMessage ) { if(CC_DEBUG) cc.log( '载入预制资源失败, 原因:' + errorMessage ); return; }
	          if( !( loadedResource instanceof cc.Prefab ) ) { if(CC_DEBUG) cc.log( '你载入的不是预制资源!' ); return; } 
	          // 开始实例化预制资源
	          Global.DialogManager.globalPrefab[prefabName] = loadedResource;
	     });
}

DialogManager.showCommonDialog = function(PrefabName, params = null, cb = null, noCancleBtn, reset = null) {
    let pNode = cc.find("Canvas") || cc.find("game");
    let target = pNode.getChildByName(PrefabName);
    if(target) return;
    let Prefab = Global.DialogManager.globalPrefab[PrefabName];
    if(!Prefab) return;
    let block = new cc.instantiate(Prefab);
    block.getComponent(PrefabName).init(params, cb, noCancleBtn, reset);
    block.parent = pNode;
   
}

DialogManager.showPopDialog = function( prefab, params ) {
     let name = prefab.name;
    if(this.showPrefabArr[name]) {
        if(CC_DEBUG) cc.log("与体制已经纯在")
        return;
    }
   
    if(CC_DEBUG) cc.log(name + "预制体的名字")
    var block = cc.instantiate( prefab );
    block.getComponent(name).dialogParameters = params;
    this.showPrefabArr[name] = block;
    block.parent = cc.find("Canvas");
}
DialogManager.hidePopDialog = function( prefabName ) {
   let name = "";
   if (typeof (prefabName) === 'object'){ 
      name = prefabName.node.name;
      if(!this.showPrefabArr[name]) {
           if(CC_DEBUG) cc.log("与字体不存在")
               return;
      }
   } else {
        name = prefabName;
        if(!this.showPrefabArr[name]) {
             if(CC_DEBUG) cc.log("与字体不存在")
                 return;
        }
   }
   if(CC_DEBUG) cc.log("关闭弹窗")
   this.showPrefabArr[name].destroy();
   delete this.showPrefabArr[name];

}

DialogManager.init = function (rootNode) {

    this.rootNode = rootNode;
    if(CC_DEBUG) cc.log(rootNode.height)
    // 创建dialog node
    this.dialogNode = new cc.Node();

    this.dialogNode.parent = this.rootNode;
    this.dialogNode.width  = rootNode.width ;
    this.dialogNode.height  = rootNode.height ;
    this.frontNode = new cc.Node();
    this.frontNode.parent = this.rootNode;
    this.frontNode.width  = rootNode.width ;
    this.frontNode.height  = rootNode.height ;
    this.showPrefabArr = {};
    Global.MessageCallback.addListener("DesignResolutionChanged", this);
};

DialogManager.allInit = function (rootNode) {
    this.init(rootNode);
    if(CC_DEBUG) console.log(this)
    this.loadedDialogPrefabs = {};
    this.uiPrefabsPath = '';
    this.createdDialogs = {};

    this.loadingCircleDialog = null;
    this.popDialog = null;
    this.globalPrefab = {};
    let globalArr = [
        'Pop/PopDialog', 
        'GameRule/gameRuleDialog', 
        'Setting/SettingDialog', 
        'Setting/CommenSettingDialog',
        "Pop/CommenTipDialog",
        "HallGame/NoticeDialog",
        "Loading/LoadingDialog",
        "Charge/ChargeVIPOpenAPPDialog",
        "Charge/ChargeDialog",
        "GameOnlineUser/gameOnlineUserDialog"
        ];


    globalArr.forEach((item, index) => {
        Global.DialogManager.addPopDailogPrefab(item);
    })
   
    Global.MessageCallback.addListener("DesignResolutionChanged", this);
};

DialogManager.messageCallbackHandler = function (route, msg) {
    if (route === "DesignResolutionChanged"){
        DialogManager.updateDialogNodeSize(msg);
    }
};

DialogManager.updateDialogNodeSize = function (size) {
    this.dialogNode.width  = size.width ;
    this.dialogNode.height  = size.height ;

    this.frontNode.width  = size.width ;
    this.frontNode.height  = size.height ;
};


DialogManager.addTip = function(tip) {
    this.createDialog("HallGame/TipDialog",{tip: tip});
}

/**
 * 创建dialog
 * @param dialogRes dialog种类，必须与prefab和dialog对应的管理js脚本名字相同
 * @param params 创建dialog需要传入的参数
 * @param cb 创建完成的会调
 */
DialogManager.createDialog = function (dialogRes, params, cb) {
    if(CC_DEBUG) cc.log('创建预制节点' + dialogRes);
    var callback = ((typeof cb) === 'function') ? cb:null;
    var fileName = dialogRes;
    var arr = dialogRes.split('/');
    var dialogType = arr[arr.length-1];
    // 验证数据
    if (!dialogRes){
        if(CC_DEBUG) console.error('Create Dialog failed: dialog type is null');
        if (!!callback) callback("create failed", null);
        return;
    }

    var createdDialogs = this.createdDialogs;
    // 判定是否已创建
    var createDialog = createdDialogs[dialogRes] || null;
    if (!!createDialog){
        if(CC_DEBUG) console.error('Create dialog is exist');
        createDialog.zIndex += 1;
        if (!!callback) callback(null, createDialog);
    }
    else{

        // 加载过则直接创建
        var loadedDialogPrefabs = this.loadedDialogPrefabs;
        if (!!loadedDialogPrefabs[dialogRes]){
            createDialog = cc.instantiate(loadedDialogPrefabs[dialogRes]);
            createdDialogs[dialogRes] = createDialog;
            createDialog.getComponent(dialogType).dialogParameters = params;
            createDialog.getComponent(dialogType).isDestroy = false;
            createDialog.parent = this.dialogNode;
            if (!!callback) callback(null, createDialog);
            return;
        }
        // 现加载资源创建
        var self = this;
        cc.loader.loadRes(fileName, function(err, data){
            if(CC_DEBUG) cc.log("我从resouce读资源")
            if (!!err){

                if (!!callback) callback(err, null);
                if(CC_DEBUG) console.error(err);
            }
            else{
                if(CC_DEBUG) cc.log(dialogRes + "+++++++++++++++++++++++++++++")
                loadedDialogPrefabs[dialogRes] = data;

                createDialog = cc.instantiate(data);

                createdDialogs[dialogRes] = createDialog;

                createDialog.getComponent(dialogType).dialogParameters = params;

                createDialog.getComponent(dialogType).isDestroy = false;
                createDialog.parent = self.dialogNode;

                if (!!callback) callback(null, createDialog);
            }
        });
    }
};


DialogManager.isDialogExit = function(dialogRes) {
    var createDialog = this.createdDialogs[dialogRes];
    if(createDialog) {
        return true;
    } else {
        return false;
    }
};

/**
 * 将dialog添加进dialogManager
 * @param dialogType dialog类型
 * @param dialog dialog节点
 */
DialogManager.addDialogToManager = function (dialogType, dialog) {
    this.createdDialogs[dialogType] = this.createdDialogs[dialogType] || dialog;
};

/**
 * 删除dialog
 * @param dialogRes 删除的dialog类型
 * @param isClearPrefabs 是否清除dialog对应的prefab
 */
DialogManager.destroyDialog = function (dialogRes, isClearPrefabs) {
    if(CC_DEBUG) cc.log(dialogRes +"+++++++++++++++++++++++")
    isClearPrefabs = isClearPrefabs || false;
    var createdDialogs = this.createdDialogs;
    var dialog = null;
    var dialogController = null;
    var dialogKey = null;
    if (typeof (dialogRes) === 'object'){
        dialog = dialogRes.node;
        dialogController = dialogRes;

        for (var key in createdDialogs){
            if (createdDialogs.hasOwnProperty(key)){
                if (createdDialogs[key] === dialog){
                    dialogKey = key;
                    break;
                }
            }
        }
    } else{
        dialog = createdDialogs[dialogRes] || null;

        var arr = dialogRes.split('/');
        var dialogType = arr[arr.length-1];

        if(dialog) {
            dialogController = dialog.getComponent(dialogType);
        }

        dialogKey =dialogRes;
    }
    if (!dialog){
        if(CC_DEBUG) console.error('destroy dialog not exist:' + dialogRes);
    }
    else{
        // 删除界面
        if(CC_DEBUG) cc.log(this.loadedDialogPrefabs[dialogKey])
        dialog.destroy();
        dialogController.isDestroy = true;
        // 移除属性
        delete createdDialogs[dialogKey];
        if (isClearPrefabs || true){
            var fileName = this.uiPrefabsPath + dialogKey;

            cc.loader.releaseRes(fileName);
            if(CC_DEBUG) cc.log(dialogKey + "删除界面++++++++++++++++++++++++++")
            if(CC_DEBUG) cc.log(this.loadedDialogPrefabs[dialogKey])
            var deps = cc.loader.getDependsRecursively( this.loadedDialogPrefabs[dialogKey] );
            cc.loader.release(deps);


            delete this.loadedDialogPrefabs[dialogKey];
        }
        if(CC_DEBUG) cc.log('destroy dialog succeed:' + dialogKey);
    }
};

DialogManager.destroyAllDialog = function(){
    if(CC_DEBUG) cc.log('destroyAllDialog');
    for (var key in this.createdDialogs){
        if (this.createdDialogs.hasOwnProperty(key)){
            var dialog = this.createdDialogs[key];
            // 删除界面
            dialog.destroy();
            var arr = key.split('/');
            var dialogType = arr[arr.length-1];
            dialog.getComponent(dialogType).isDestroy = true;
            // 移除属性
            delete this.createdDialogs[key];
            delete this.loadedDialogPrefabs[key];
            cc.loader.releaseRes(key);
        }
    }
};

DialogManager.addLoadingCircle = function (delay){
    var self = this;
    if (!this.loadingCircleDialog){
        cc.loader.loadRes('Loading/LoadingCircleDialog', function(err, data){
            if (!err){
                self.loadingCircleDialog = cc.instantiate(data);
                self.loadingCircleDialog.parent = self.frontNode;
                self.loadingCircleDialog.zIndex = 1;
                var loadingCircleDialog = self.loadingCircleDialog.getComponent('LoadingCircleDialog');
                if (!!loadingCircleDialog) loadingCircleDialog.addLoadingCircle(delay);
            }
        });
    }
    else{
        var loadingCircleDialog = self.loadingCircleDialog.getComponent('LoadingCircleDialog');
        if (!!loadingCircleDialog) loadingCircleDialog.addLoadingCircle(delay);
    }
};

DialogManager.removeLoadingCircle = function (){
    if (!!this.loadingCircleDialog){
        var loadingCircleDialog = this.loadingCircleDialog.getComponent('LoadingCircleDialog');
        if (!!loadingCircleDialog) loadingCircleDialog.removeLoadingCircle();
    }
};

DialogManager.addPopDialog = function(content, cbOK, cbCancel, isRotate ){
    var self = this;
    if (!this.popDialog){
        cc.loader.loadRes('Pop/PopDialog', function(err, data){
            if (!err){
                self.popDialog = cc.instantiate(data);
                self.popDialog.parent = self.frontNode;
                self.popDialog.zIndex = 1;
                var popDialog = self.popDialog.getComponent('PopDialog');
                if (!!popDialog) popDialog.addPopDialog(content, cbOK, cbCancel, isRotate);
            }
        });
    }
    else{
        var popDialog = self.popDialog.getComponent('PopDialog');
        if (!!popDialog) popDialog.addPopDialog(content, cbOK, cbCancel, isRotate);
    }
};

DialogManager.removeLastPopDialog = function(){
    if (!!this.popDialog){
        var popDialog = this.popDialog.getComponent('PopDialog');
        if (!!popDialog) popDialog.removeLastPopDialog();
    }
};

DialogManager.addTipDialog = function (content, cb) {
    this.createDialog('Pop/TipDialog', {content: content, cb: cb});
};
