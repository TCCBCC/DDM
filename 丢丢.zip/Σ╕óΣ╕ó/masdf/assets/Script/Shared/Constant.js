let Constant = module.exports = {};

//window.GAME_RELASE_PLATFORM 在main.js声明 玩
Constant.apkName = "erer"; // GHX
Constant.relase = "onlinePublick"; //  ip地址
Constant.subGameBuildType = "onlinePublick"; // 下载子游戏地址配置

if(Constant.apkName === "HX") {
	switch( Constant.relase ) { 
		case "onlinePublick": // 发布版本
			Constant.tingfuAddress = "" ; //停服华夏网关
			Constant.tingfuAddressBeiYong = [];
			break;
		case "onlineRelease": // 线上测试版
			Constant.tingfuAddress = "" ; //停服
			Constant.tingfuAddressBeiYong = []; //停服
			break;
		case "offLineDubug": // 线下版本，本机offLineDubug
			//Constant.tingfuAddress = "http://192.168.50.114:1002" ; //停服
			Constant.tingfuAddress = "" ; //停服
			Constant.tingfuAddressBeiYong = [""] ; //停服
			break;
		case "offLineRelease":
			Constant.tingfuAddress = "" ; // 停服
			break;
	}
} else {
	switch( Constant.relase ) { 
		case "onlinePublick": // 发布版本
			Constant.tingfuAddress = "" ; //停服华夏网关
			Constant.tingfuAddressBeiYong = [] ; //停服
			break;
		case "onlineRelease": // 线上测试版
			
			Constant.tingfuAddress = "" ; //停服
			Constant.tingfuAddressBeiYong = [] ; //停服
			break;
		case "offLineDubug": // 线下版本，本机offLineDubug
			Constant.tingfuAddress = "" ; //停服
			break;
	}

}

// Constant.port = ":13005"


// Constant.gameServerAddress = Constant.serverAddress + Constant.port;

Constant.operationAddress = Constant.tingfuAddress ; // 第三方服务器地址



// Constant.imgServerAddress = Constant.webServerAddress + '/';          // 图片缓存服务器

Constant.test = false;
Constant.subGameDownStatus = {};

// 登录计时器
Constant.timeOutTime = 20;
Constant.everyTime = 1000;
Constant.loginTime = 0;
Constant.loginTimer = null;
Constant.shouldGoInGame = false;

Constant.httpTimeout = 20000;
