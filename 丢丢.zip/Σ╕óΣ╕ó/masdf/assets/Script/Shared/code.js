var constant = function () {
    this.OK = 0;
    this.FAIL = 1;
    this.REQUEST_DATA_ERROR = 2;                    // 请求数据错误
    this.MYSQL_ERROR = 3;                           // 数据库操作错误
    this.INVALID_UERS = 4;                          // 无效用户
    this.INVALID_PARAM = 5;                         //发送参数错误
    this.PERMISSION_NOT_ENOUGH = 6;                 // 权限不足
    this.SMS_CODE_ERROR = 7;                        // 短信验证码错误
    this.IMG_CODE_ERROR = 8;                        // 图形验证码错误

    this.SMS_AUTH_CONFIG_ERROR = 9;                 // 短信验证配置信息错误
    this.SMS_SEND_FAILED = 10;                      // 短信发送失败
    this.SHORT_PARAM = 11;                      // 缺少参数
    this.PHONE_ERROR = 12;                      // 账号必须为11位手机号码
    this.PASSWORD_ERROR = 13;                      // 密码不符合规范，请重新输入
    this.UNLOCK_USER = 14 ;                       // 用户被冻结
    this.CONFIG_NOT_LOAD = 15;                     // 配置加载中;
    this.LOGIN = {
        ACCOUNT_OR_PASSWORD_ERROR: 103,             // 账号或密码错误
        GET_HALL_SERVERS_FAIL: 104,                 // 获取大厅服务器失败
        ACCOUNT_EXIST:105,                          // 账号已存在
        ACCOUNT_NOT_EXIST: 106,                     // 帐号不存在
        ANSWER_ERROR: 107,                           // 密保问题答案错误
        PASSWORD_ERROR: 108,                        // 密码错误
        IP_ERROR: 109,                             // 服务器正在维护中...
    };
    this.HALL = {
        TOKEN_INFO_ERROR: 201,                       // token信息错误
        TOKEN_INVALID: 202,                          // token失效

        TODAY_ALREADY_SIGNED: 203,                    // 今日已签到
        TODAY_ALREADY_SHARED: 204,                    // 今日已分享

        NOT_SPREAD_REWARDS: 205,                     // 没有可领取的推广奖励

        NOT_ENOUGH_GOLD: 206,                       // 金币不足
        NOT_ENOUGH_DIAMOND: 207,                    // 钻石不足

        ALREADY_IN_FRIEND_LIST: 208,                // 已经在好友列表中
        ALREADY_IN_REQUEST_LIST: 209,               // 已经在请求列表中
        NOT_IN_FRIEND_LIST: 210,                    // 不再好友列表中
        NOT_IN_REQUEST_LIST: 211,                   // 不再请求列表中
        NOT_FIND: 212,                              // 未找到该用户

        CAN_NOT_EVALUATE_TODAY: 213,                 // 今日评价次数已达上限
        SPREAD_ID_ALREADY_SET: 214,                  // 已设置过推广ID，无法重复设置
        NOT_FIND_TRADE_ORDER: 215,                   // 未查询到订单信息
        BROADCAST_STRING_TOO_LONG: 216,              // 广播字符数量太长
        BIND_PHONE_ALREADY: 217,                     // 手机号已被绑定
        BIND_WX_ALREADY: 218,                        // 微信已经被绑定
        TRADE_INFO_NOT_FIND: 219,                    // 订单不存在
        NOT_ENOUGH_VIP_LEVEL: 220,                   // vip等级不足
        INVITED_FRIEND_OFFLINE: 221,                 // 好友不在线

        CAN_NOT_CHANGE_USER_INFO_BECAUSE_INTERVAL_TIME: 222,   // 个人资料三十天才能改变一次

        NICKNAME_TO_LONG: 223,                          // 名字太长
        NO_LOGIN: 224,                                  // 帐号被冻结，禁止登录
        TODAY_ALREADY_WITHDRAW_CASH: 225,               // 今日已退款
        NOT_SPREADER: 226,                              // 非推广员
        NOT_ENOUGH_COUPON: 227,                         // 积分不足
        ALREADY_SPREADER: 228,                          // 该用户已经为推广员
        GOLD_LOCKED: 229,                               // 当前正在游戏中无法操作金币
        SAFE_PASSWORD_ERROR: 230,                       // 保险柜密码错误

        NOT_BIND_ALI_PAY: 231,                          // 未绑定支付宝
        NOT_BIND_BANK_CARD: 232,                         // 未绑定银行卡
        NICKNAME_HAS_USED: 233,                         // 昵称已经被使用
        USER_HAS_BIND_PHONE: 234,                         // 已经绑定了手机号
        NOT_RECEIVE_EMAIL: 235,                         // 没有可领取的邮件
        MIN_WITHDRAW_CASH: 236,                         // 小于最小提取金额
        WITHDRAW_SUCCESS: 237,                       // 提现申请已提交，稍后即将到账
        BIND_SMS_SUCCESS: 238,                       // 验证码发送成功
        GOLD_MIN_KEEP: 239,                       // 超过最大提取额
        GOLD_START_WITHDRAW_CASH: 240,                       // 小于最小起提额
        ALIPAY_ERROR: 241,                       // 支付宝账号不符合规范
        CAN_NOT_WITHDRAW: 244,                    //打码量不够无法体现
        LIMIT_WITHDRAW: 245,                     //提现失败，如有疑问请联系客服
        BIND_WITHDRAW: 246,                     // 绑定失败，如有疑问请联系客服
        NICKNAME_INVALID: 248,                     // 只能输入汉字英文数字下划线
        ONE_COPY_WITHDRAW_: 249,                     // 您有一笔未处理提现
        ALREADY_BIND_ALI_PAY: 250,                     //  该支付宝账号已被绑定，无法重复绑定
        ALREADY_BIND_BANK_CARD: 251,                     // 该银行卡账号已被绑定，无法重复绑定
        ACCOUNT_BIND_SUCCESS: 252,                     // 已有兑换成功记录或正在处理的订单，无法修改
        CAN_NOT_CLICK: 16,                     //请勿重复点击
        POINTS_NOT_ENOUGH: 2004,              //积分不足
        // this.ACTIVITY_UPKEEP = 2005;

    };

    this.GAME_CENTER = {
        ENTERING_ROOM_CANT_MATCH: 301,               // 正在进入房间无法重新匹配
        GAME_SERVER_PARAMETER_ERROR: 302,            // 游戏服务器参数错误
        MATCHING: 303,                               // 正在匹配
        ENTERING_ROOM: 304,                          // 正在进入房间
        NOT_IN_MATCH_LIST: 305,                      // 没有在匹配队列中
        ALREADY_IN_ROOM: 306,                        // 已经在房间中，无法创建新的房间
        CREATE_ROOM_ERROR: 307,                      // 创建房间失败
        ROOM_NOT_EXIST:308,                          // 房间不存在
        ROOM_PLAYER_COUNT_FULL: 309,                // 房间人数已满
        JOIN_ROOM_ERROR: 310,                       // 加入房间失败
        ENTRY_ROOM_FAIL_GOLD_NOT_ENOUGH: 311,       // 进入房间失败，金币不足
        ENTRY_ROOM_FAIL_GOLD_TOO_MANY: 312,          // 进入房间失败，金币超过上限
    };
    this.GAME = {
        ROOM_COUNT_REACH_LIMIT: 401,                  // 房间数量到达上线
        LEAVE_ROOM_GOLD_NOT_ENOUGH_LIMIT: 402,        // 金币不足，无法开始游戏
        LEAVE_ROOM_GOLD_EXCEED_LIMIT: 403,            // 金币超过最大限度，无法开始游戏
        ROOM_EXPENSE_NOT_ENOUGH: 404,                 // 房费不足
        ROOM_HAS_DISMISS: 405,                        // 房间已解散
        ROOM_HAS_DISMISS_SHOULD_EXIT: 406,             // 房间已解散，请离开房间
        CAN_NOT_LEAVE_ROOM: 407,                     // 正在游戏中无法离开房间
        GAME_RECORD_EXIST_NO_EXTRACT: 408,          // 请提取中奖金额
        GAME_RECORD_EXIST_SPECIAL: 409,             // 请继续特殊游戏
        GAME_GET_MONEY_FAIL: 410,             // 提取金钱失败
        CAN_NOT_BE_BANK: 413,                 //已经是庄家，无法上庄
        BANK_LIST_FULL: 414,                  //庄家队列已满，请稍后重试
        HAS_BE_BANK: 415,                     //您已经成为本局庄家，无法取消
        CAN_NOT_CANCEL_BANK: 416,              //您未在庄家队列中，无法取消
        NOT_ENOUGH_GOLD:417,                   // 您的金币不足10000，不能上庄
        NOT_ENOUGH_NEXTBANK: 418,
        NOT_ENOUGH_BEBANK: 419,
    };

    this.RECHARGE = {
        RECHARGE_FAIL: 501,                             // 充值失败
        RECHARGE_SUCCESS: 502,                          // 充值成功
        USER_NOT_FIND: 503,                             // 未找到用户
        ITEM_NOT_FIND: 504,                             // 未找到商品信息
        SIGN_CHECK_ERR: 505,                            // 签名验证错误
        MONEY_COUNT_ERR: 506,                           // 充值金额错误
        ITEM_INFO_ERR: 507,                             // 商品信息错误
        USER_PAYMENT_FAILED: 508                        // 用户支付失败
    };

    this.ACTIVITY = {
        NOT_EXIST: 601,
        NOT_STARTED: 602,
        HAS_END: 603,
        POINT_NOT_ENOUGH: 604,
        REQUEST_MANY: 605
    }



};
module.exports = new constant();
