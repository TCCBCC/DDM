

cc.Class({
    extends: cc.Component,

    properties: {
      LoginBox: cc.Node,
      VideoBox: cc.Node,
      KFBtnNode: cc.Node
    },
    onLoad () { // bubufufd
        // cc.macro.SUPPORT_TEXTURE_FORMATS = [".pkm", ".pvr", ".webp", ".jpg", ".jpeg", ".bmp", ".png",".pkm"];
        // cc.log("pkmpkmpkmpkmpkmpkmpkmpkmpkmpkmpkmpkmpkm")
        cc.HallAndSubGameGlobal = {};
        // Global.CCHelper.screenAdaptation(new cc.Size(1280, 720), this.node.getComponent(cc.Canvas));
        if( !Global.firstComeToGame ) { // 第一次启动app
            this.initGlobal(); // 初始化全局数据
            this.playViedo();
            Global.CCHelper.GHXShowKFBtn( this.KFBtnNode );
        } else {
            Global.CCHelper.screenAdaptation(new cc.Size(1280, 720), this.node.getComponent(cc.Canvas));
            this.LoginBox.active = true;
            Global.CCHelper.GHXShowKFBtn( this.KFBtnNode );
        }
        Global.leveUp = " ";

      


    },
    playViedo() {
      // Global.CCHelper.screenAdaptation(new cc.Size(1280, 720), this.node.getComponent(cc.Canvas));
      
      let isHotUpdate = cc.sys.localStorage.getItem('isHotUpdate');
      if( isHotUpdate == "true") {  // 重启
        this.LoginBox.active = true;
        cc.sys.localStorage.setItem('isHotUpdate', "false")
      } else {
        if( CC_DEBUG ) {
           this.LoginBox.active = true;
           return; 
        }

        this.VideoBox.active = true; // clicked 

        this.VideoBox.on('completed', function() {
          this.VideoBox.active = false;
          this.LoginBox.active = true;
        }, this);
        this.VideoBox.on('clicked', function() {
          this.VideoBox.active = false;
          this.LoginBox.active = true;
        }, this);

        setTimeout(() => {

          this.VideoBox.getComponent(cc.VideoPlayer).isFullscreen = true;
          this.VideoBox.getComponent(cc.VideoPlayer).play();
        }, 0);

      }

    },
    vedioClick() {
    	this.VideoBox.active = false;
    	this.LoginBox.active = true;
    },



    initGlobal: function(){

        Global.animationDisplay = [];

        Global.Constant = require('./Constant');
        Global.MessageCallback = require('./MessageCallback');
        Global.DialogManager = require('./DialogManager');
        if( !Global.AudioManager ) {
            Global.AudioManager = require('./AudioManager');
            Global.AudioManager.init();
        }

        Global.NetworkManager = require('./NetworkManager');

        Global.CCHelper = require('./CCHelper');
        Global.Utils = require('./utils');

        Global.NetworkLogic = require('./NetworkLogic');

        Global.Enum = require('./enumeration');
        Global.Code = require('./code');
        Global.UmengNative = require("UmengNative");
        Global.API = require('./Api');
        Global.CCHelper.screenAdaptation(new cc.Size(1280, 720), this.node.getComponent(cc.Canvas));
        Global.DialogManager.allInit(this.node);
        Global.headerArr = this.headerArr;
        // Global.SDK = require('./SDK');

        Global.Player = require('../Models/Player');
        // Global.RoomProto = require("../Models/RoomProto");
        // Global.PlayerWechat = require('../Models/PlayerWechat');
        // Global.GameTypes = require('../Models/GameTypes');
        // Global.Data = require('../Models/Data');

        // Global.Animation = require('./Animation');
        // Global.AgentProfit = require('../Models/AgentProfit');
        // Global.avatarArr = this.avatarArrSprite; // 挂在全局头像
        // 头像
        Global.avatarArr = [];
        Global.VIPFrame = [];
        // this.DealMulityEventListener();
        cc.loader.loadResDir("SettingAvatar", function(err, assets){
            if(err || assets.length <= 0)  return;
            assets.forEach((item, inde) => {
                if(item.name) {
                    Global.avatarArr.push(item);
                }
            })

        });
        cc.loader.loadResDir("VIPFrame", function(err, assets){
            if(err || assets.length <= 0)  return;
            assets.forEach((item, inde) => {
                if(item.name) {
                    Global.VIPFrame.push(item);
                }
            })

        });



        

        



    },





 
    start () {

    },
    onDestroy() {
         // Global.MessageCallback.removeListener('optionLogo', this);
    }

    // update (dt) {},
});
