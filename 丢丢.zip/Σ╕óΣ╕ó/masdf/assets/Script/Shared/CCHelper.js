let utils = require("./utils");
let code = require("./code");
let SubgameManager = require('../HotUpdate/SubgameManager');
let auth = require("auth");
var exp = module.exports = {};
var openinstall = require("OpenInstall");



exp.getRelativePosition = function (childNode, parentNode) {
    return parentNode.convertToNodeSpace(childNode.parent.convertToWorldSpace(childNode.position));
};



//跨域图片或者本地图片
exp.setSpriteFrame = function (imgUrl, target_, cb) {
    let target = target_;

    if ((imgUrl && imgUrl.indexOf('http') >= 0)) {
        cc.loader.load(imgUrl , function (err, texture) {
            
            if (!!err) {
               
                cc.error(err);
                utils.invokeCallback(cb, err);
            } else {
               
                if (target.isValid) {
                    target.spriteFrame = new cc.SpriteFrame(texture);
                    utils.invokeCallback(cb);
                }
            }
            cb(err);
        });
        //加载本地图片
    } else {
        cc.loader.loadRes(imgUrl, cc.SpriteFrame, function (err, spriteFrame){
            if (!!err){
                if(CC_DEBUG) cc.log(err);
                utils.invokeCallback(cb, err);
            }else{
                if (target.isValid){
                    target.spriteFrame = spriteFrame;
                    utils.invokeCallback(cb);
                }
            }
            cb(err);
        });
    }
};



exp.httpRequest = function (params) { // ajax 请求
    if(CC_DEBUG) cc.log(params)
    if(CC_DEBUG) cc.log('请求url:', params.url);
    // if(CC_DEBUG) cc.log('请求数据:', JSON.stringify(params.data));
    let urlStr = params.url;
    let methodStr = params.method || 'GET';
    let responseType = params.responseType || 'json';


    if( Global.xhr ) {
        // Global.xhr.abort();
    }

    if(window.XMLHttpRequest) {
            Global.xhr = new XMLHttpRequest();
    } else {
            Global.xhr = new ActiveXObject("Microsoft.XMLHTTP");
    }

    Global.xhr.responseType = responseType;
    Global.xhr.onload = function () {
        if(responseType === "json"){
            if(CC_DEBUG) cc.log(Global.xhr.response)
            // if(CC_DEBUG) cc.log('收到数据:', JSON.stringify(Global.xhr.response ));
        }else{
            if(CC_DEBUG) cc.log('收到数据2:',Global.xhr.responseText);
        }
        if (Global.xhr.status === 200){ // 成功
            utils.invokeCallback(params.cb, null, Global.xhr.response);
        } else {
            cc.error("请求失败：status=" + Global.xhr.status);
            Global.DialogManager.removeLoading(); // ---------------------------------------
            utils.invokeCallback(params.cb, "请求失败");
        }
    };
    Global.xhr.onerror = function(e) {
        utils.invokeCallback(params.cb, "无网络请求失败");
        if(CC_DEBUG) cc.log(e);
    }
    Global.xhr.timeout = Global.Constant.httpTimeout;
    Global.xhr.ontimeout = function (e) {
        // XMLHttpRequest 超时。在此做某事。
        cc.error("请求超时:", JSON.stringify(Global.xhr.response));
        Global.DialogManager.removeLoading(); // -------------------------------
        let data = {};
        data.code = 9999;
        utils.invokeCallback(params.cb, null, data);
    };
    Global.xhr.open(methodStr, urlStr, true);
    Global.xhr.setRequestHeader("CONTENT-TYPE", "application/x-www-form-urlencoded");
    if (!!params.data) {
        let data = "";
        for (let key in params.data){
            if (params.data.hasOwnProperty(key)){
                if (data.length > 0){
                    data += "&";
                }
                data += (key + "=" + params.data[key]);
            }
        }
        if(data.length > 0){
            
            Global.xhr.send(data);
        }else{
            
            Global.xhr.send();
        }
    } else {
        
        Global.xhr.send();
        
    }
};

exp.screenShoot = function (cb) {
    if (!cc.sys.isNative) return;
    if (CC_JSB) {
        let dirpath = jsb.fileUtils.getWritablePath() + 'ScreenShoot/';
        if (!jsb.fileUtils.isDirectoryExist(dirpath)) {
            jsb.fileUtils.createDirectory(dirpath);
        }
        let name = 'ScreenShoot-' + (new Date()).valueOf() + '.png';
        let filepath = dirpath + name;
        let size = cc.visibleRect;
        let rt = cc.RenderTexture.create(size.width, size.height);
        cc.director.getScene()._sgNode.addChild(rt);
        rt.setVisible(false);
        rt.begin();
        cc.director.getScene()._sgNode.visit();
        rt.end();
        rt.saveToFile('ScreenShoot/' + name, cc.ImageFormat.PNG, true, function () {
            if(CC_DEBUG) cc.log('save succ');
            rt.removeFromParent(true);
            utils.invokeCallback(cb, null, filepath);
        });
    }
};

// 截屏
exp.capScreen = function(node) {
    if (true) {
        let node = new cc.Node();
node.parent = cc.director.getScene();
let camera = node.addComponent(cc.Camera);

// 设置你想要的截图内容的 cullingMask
camera.cullingMask = 0xffffffff;

// 新建一个 RenderTexture，并且设置 camera 的 targetTexture 为新建的 RenderTexture，这样 camera 的内容将会渲染到新建的 RenderTexture 中。
let texture = new cc.RenderTexture();
texture.initWithSize(cc.visibleRect.width, cc.visibleRect.height);
camera.targetTexture = texture;

// 渲染一次摄像机，即更新一次内容到 RenderTexture 中
camera.render();

// 这样我们就能从 RenderTexture 中获取到数据了
let data = texture.readPixels();

// 接下来就可以对这些数据进行操作了

let canvas = document.createElement('canvas');
let ctx = canvas.getContext('2d');
canvas.width = texture.width;
canvas.height = texture.height;
let width = canvas.width;
let height = canvas.height
let rowBytes = width * 4;
for (let row = 0; row < height; row++) {
    let srow = height - 1 - row;
    let imageData = ctx.createImageData(width, 1);
    let start = srow*width*4;
    for (let i = 0; i < rowBytes; i++) {
        imageData.data[i] = data[start+i];
    }

    ctx.putImageData(imageData, 0, row);
}

let dataURL = canvas.toDataURL("image/jpeg");
cc.log(dataURL)
let img = document.createElement("img");
img.src = dataURL;
cc.log(img)
    }
};

// 刷新对齐
exp.updateNodeAlignment = function (node) {
    let widget = node.getComponent(cc.Widget);
    if (!!widget){
        widget.updateAlignment();
    }
    for (let i = 0; i < node.children.length; ++i) {
        exp.updateNodeAlignment(node.children[i]);
    }
};

// 屏幕适配
exp.screenAdaptation = function (baseSize, canvas) {
    let size = new cc.size(baseSize.width, baseSize.height);
    let frameSize = cc.view.getFrameSize();
    if (size.height/size.width < frameSize.height/frameSize.width){
        size.height = size.width * (frameSize.height / frameSize.width);
    } else{
        size.width = size.height * (frameSize.width/frameSize.height);
    }
    canvas.designResolution = size;

    canvas.node.width = size.width;
    canvas.node.height = size.height;

    if(cc.sys.isNative) return;
    cc.view.setResizeCallback(function (){
        size = new cc.size(baseSize.width, baseSize.height);
        frameSize = cc.view.getFrameSize();
        if (size.height/size.width < frameSize.height/frameSize.width){
            size.height = size.width * (frameSize.height / frameSize.width);
        } else{
            size.width = size.height * (frameSize.width/frameSize.height);
        }
        canvas.designResolution = size;
        canvas.node.width = size.width;
        canvas.node.height = size.height;

        Global.MessageCallback.emitMessage("DesignResolutionChanged", size);

        exp.updateNodeAlignment(canvas.node);
    });
};

exp.playPreSound = function () {
    cc.loader.loadRes('Sound/button', function (err, clip) {
        if (!!err) {} else {
            cc.audioEngine.play(clip, false, 0);
        }
    });
};

exp.popPuLayer = function(node, s = 0.96) { // 弹出层
    node.active = true;
    // node.active = true;
    node.scale = 0.85 * s;
    node.runAction(cc.scaleTo(0.3, 1 * s).easing(cc.easeBackOut()));
}


//跨域图片或者本地图片
exp.updateSpriteFrame = function (imgUrl, target_, cb, cbFail) { //cfdff
    let target = target_;
    if ((imgUrl && imgUrl.indexOf('http') >= 0)) {
        cc.loader.load({url: imgUrl, type: "png"}, function (err, texture) {
            if (!!err) {
                if(cbFail) cbFail();
                cc.error(err);
                utils.invokeCallback(cb, err);
            } else {
                if (target.isValid) {
                    target.spriteFrame = new cc.SpriteFrame(texture);
                    if(cb) cb();
                    utils.invokeCallback(cb);
                }
            }
        });
        //加载本地图片
    } else {
        cc.loader.loadRes(imgUrl, cc.SpriteFrame, function (err, spriteFrame){
            if (!!err){
                if(CC_DEBUG) cc.log(err);
                utils.invokeCallback(cb, err);
            }else{
                if (target.isValid){
                    target.spriteFrame = spriteFrame;
                    utils.invokeCallback(cb);
                }
            }
        });
    }
};


//检查是不是微信浏览器
exp.isWechatBrowser = function () {
    //安卓的微信webview由qq浏览器x5内核提供技术支持，所以加BROWSER_TYPE_MOBILE_QQ
    return false;
    //return (cc.sys.browserType === cc.sys.BROWSER_TYPE_WECHAT || cc.sys.browserType === cc.sys.BROWSER_TYPE_MOBILE_QQ);
};


exp.setPageTitle = function(titleText) {
    if(!cc.sys.isBrowser) return;
    document.title = titleText;
};


// 获取单位向量
exp.getUnitVector = function (startPoint, endPoint) {
    let point = cc.v2(0, 0);
    let distance;
    distance = Math.pow((startPoint.x - endPoint.x), 2) + Math.pow((startPoint.y - endPoint.y),2);
    distance = Math.sqrt(distance);
    if(distance === 0) return point;
    point.x = (endPoint.x - startPoint.x)/distance;
    point.y = (endPoint.y - startPoint.y)/distance;
    return point;
};


exp.createFrameAnimationNode = function (res, cb) {
    cc.loader.loadRes(res + "_config", cc.JsonAsset, function (err, data) {
        if (!!err){
            cc.error("createFrameAnimation err: load file fail url=" + res + '.json');
            cb("load file fail");
        }else{
            data = data.json;
            let width = data["width"] || 0;
            let height = data["height"] || 0;
            let count = data["count"] || 0;
            let intervalTime = (data["intervalTime"] || 0);
            if (width <= 0 || height <= 0 || count <= 0 || intervalTime <= 0){
                cc.error("animation data err");
                cb("animation data err");
                return;
            }
            cc.loader.loadRes(cc.url.raw(res + '.png'), function (err, texture) {
                if (!!err){
                    cc.error("createFrameAnimation err: load file fail url=" + res + '.png');
                    cb("load file fail");
                }else{
                    let wCount = Math.floor(texture.width/width) || 1;
                    let hCount = Math.floor(texture.height/height) || 1;

                    let node = new cc.Node();
                    let sprite = node.addComponent(cc.Sprite);
                    sprite.spriteFrame = new cc.SpriteFrame(texture, new cc.Rect(0, 64, width, height));
                    /**
                     * @param loop 是否循环，默认false
                     * @param speed 播放速度，默认1
                     * @param completeCallback，每完成一次的回调
                     */
                    node.startAnimation = function (loop, speed, completeCallback) {
                        if (!speed || speed <= 0) speed = 1;
                        intervalTime = intervalTime/speed;
                        node.stopAllActions();
                        let index = 0;
                        function callback() {
                            let curIndex = index++ % data.count;
                            let rect = new cc.Rect((curIndex%wCount) * width, Math.floor(curIndex/hCount) * height, width, height);
                            sprite.spriteFrame = new cc.SpriteFrame(texture, rect);
                            if(!!completeCallback && (curIndex === (data.count - 1))){
                                completeCallback();
                            }
                        }
                        if (!!loop){
                            node.runAction(cc.repeatForever(cc.sequence([cc.delayTime(intervalTime), cc.callFunc(callback)])));
                        }else{
                            node.runAction(cc.repeat(cc.sequence([cc.delayTime(intervalTime), cc.callFunc(callback)]), data.count));
                        }
                    };
                    node.stopAnimation = function () {
                        node.stopAllActions();
                    };
                    cb(null, node);
                }
            })
        }
    });
};

exp.createSpriteNode = function (src) {
    let node = new cc.Node();
    let sprite = node.addComponent(cc.Sprite);
    sprite.spriteFrame = new cc.SpriteFrame();
    exp.updateSpriteFrame(src, sprite);
    return node;
};

exp.loadRes = function (dirArr, cb) {
    let loadingCount = 0;
    for (let i = 0; i < dirArr.length; i ++) {
        cc.loader.loadResDir(dirArr[i], function (err) {
            loadingCount += 1;
            if (loadingCount >= (dirArr.length)) {
                utils.invokeCallback(cb, err);
            }
        }.bind(this));
    }
};



//获取设备号
exp.getDeviceID = function() {


    let deviceInfo = {};


    if(!cc.sys.isNative) {
         deviceInfo.osType = 1
          //deviceInfo.ID = 'DFWrweewando121'; //绑定手机号了的
          deviceInfo.ID = 'DFWrweewa23232333345';
         // deviceInfo.ID = 'fdfdsf212fdfd';
        return deviceInfo;
    }
    if(cc.sys.os == cc.sys.OS_IOS){ // 苹果

        deviceInfo.ID = jsb.reflection.callStaticMethod("KTUUIDManager", "getDeviceID");
        deviceInfo.osType = 2;

    } else if(cc.sys.os == cc.sys.OS_ANDROID){ // 安卓

        deviceInfo.ID = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "getAndroidId", "()Ljava/lang/String;"); // 获取ID
        if(CC_DEBUG) cc.log("设备号:" + deviceInfo.ID );
        deviceInfo.osType = 1;
    } else { // PC

        deviceInfo.ID = 'DFWrandomID' + Math.floor(Math.random() * 1000000);
        deviceInfo.osType = 3
    }

    return deviceInfo;
}
exp.bindJPushID = function( uid ) { // 绑定uid
        
        let Uid = Number(uid) + "";
        if(!cc.sys.isNative) return;
        if(cc.sys.os == cc.sys.OS_IOS){ // 苹果
            let className = "KTTool";
            let FunName = "GetUserID:"
            jsb.reflection.callStaticMethod(className, FunName, Uid);


        } else if(cc.sys.os == cc.sys.OS_ANDROID){ // 安卓
            let className = 'org/cocos2dx/javascript/AppActivity'; // 原生类
            let FunName = 'myBindPushID'; // 原生方法名
            let JavaV = '(Ljava/lang/String;)V';
            // 调用原生方法
            jsb.reflection.callStaticMethod(className,FunName,JavaV,Uid); // 调用原生静态方法
        } 

        // return deviceInfo;
}
exp.getJPushID = function() { // 获取极光id
    let jPushID = "";
    if(!cc.sys.isNative) return jPushID;
    if(cc.sys.os == cc.sys.OS_IOS){ // 苹果
        let className = "KTTool";
        let FunName = "GetJpushRegistID"
        jPushID = jsb.reflection.callStaticMethod(className, FunName);

    } else if( cc.sys.os == cc.sys.OS_ANDROID ){ // 安卓
        jPushID = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "myGetJPushID", "()Ljava/lang/String;"); // 获取ID
    } 
    return jPushID;
}

// 跳转url
exp.jumpUrl = function(url) {

    Global.DialogManager.showCommonDialog("CommenTipDialog",'正在跳转...');
    if(cc.sys.os == cc.sys.OS_ANDROID) { // 安卓
      let className = 'org/cocos2dx/javascript/AppActivity'; // 原生类
      let FunName = 'openURL'; // 原生方法名
      let JavaV = '(Ljava/lang/String;)V';
      // 调用原生方法
      jsb.reflection.callStaticMethod(className,FunName,JavaV,url); // 调用原生静态方法
    }
    if(cc.sys.os == cc.sys.OS_IOS) { // ios
      let className = 'KTTool_ios'; // 原生类名
      let FunName = 'openSafariURL:'; // 原生方法名
      jsb.reflection.callStaticMethod(className,FunName, url);
    }
    // 调用原生方法
} // 

exp.setOrientation = function( i ) {
    if( cc.sys.os == cc.sys.OS_IOS ) {  
        let className = 'AppController'; // 原生类名
        let FunName = 'setOrientation:'; // 原生方法名
        jsb.reflection.callStaticMethod(className,FunName, i);

    } else if ( cc.sys.os == cc.sys.OS_ANDROID ) {
        let className = 'org/cocos2dx/javascript/AppActivity'; // 原生类
        let FunName = 'setOrientation'; // 原生方法名
        let JavaV = '(I)V';
        // 调用原生方法
        jsb.reflection.callStaticMethod(className,FunName,JavaV,i); // 调用原生静态方法
      
    }
} 
exp.jumpToKeFu = function() {
    var nickName = Global.Player.nickname;
    var uid = Global.Player.uid;
    var tel = Global.Player.uid.phoneAccount;
    var url = "";
    if(Global.Constant.onlineService.indexOf("?") > 0){
        url = `${Global.Constant.onlineService}&_=t&metadata={"name":"${nickName}-${uid}","tel":"${tel || ""}","qq":"${uid}"}`;
    }else{
        url = `${Global.Constant.onlineService}?_=t&metadata={"name":"${nickName}-${uid}","tel":"${tel || ""}","qq":"${uid}"}`;
    }
    Global.CCHelper.jumpUrl(url);

}
exp.copyText = function(text, Tip) {
    let ok = false;


    if(cc.sys.os == cc.sys.OS_ANDROID) {
      let className = 'org/cocos2dx/javascript/AppActivity'; // 原生类
      let FunName = 'copyToClipboard'; // 原生方法名getNetType
      let JavaV = '(Ljava/lang/String;)Z';
      // 调用原生方法
      ok = jsb.reflection.callStaticMethod(className,FunName,JavaV,text); // 调用原生静态方法
      

    } else if(cc.sys.os == cc.sys.OS_IOS) {
      ok = jsb.reflection.callStaticMethod("KTTool", "copyToPastboard:", text);
    }
    let tip = ok ? ( Tip ? Tip : '复制成功' ) : '复制失败请手动抄写';
    Global.DialogManager.showCommonDialog("CommenTipDialog",tip);

    return ok;
}

exp.getVersionName = function() {
     let version = "";
     if( cc.sys.os == cc.sys.OS_IOS ) {

        version =  jsb.reflection.callStaticMethod("KTTool", "GetAppVersion");

     } else if ( cc.sys.os == cc.sys.OS_ANDROID ) {
        let className = 'org/cocos2dx/javascript/AppActivity'; // 原生类
        let FunName = 'getVersionName'; // 原生方法名getNetType
        let JavaV = '()Ljava/lang/String;';
        // version = "10.0.0";
        // 调用原生方法
        version =  jsb.reflection.callStaticMethod(className,FunName,JavaV); // 调用原生静态方法
       
     }
     return version;
}

exp.setSubgameAvatar = function(avatarName, target) {
        for (let i = 0; i  < Global.avatarArr.length; i++) {
            if( Global.avatarArr[i].name == avatarName ) {
                target.spriteFrame = Global.avatarArr[i];
                break;
            }
        }
}
exp.setSubgameFrame = function( index , target) {
        for (let i = 0; i  < Global.VIPFrame.length; i++) {
            if( Global.VIPFrame[i].name == "lv" + index) {
                target.spriteFrame = Global.VIPFrame[i];
                break;
            }
        }
}

exp.loginTimeFun = function(loginNode) {
    if(Global.Constant.loginTimer) {
        clearInterval( Global.Constant.loginTimer );
    } 
    // 登录计时器
    Global.Constant.loginTime = 0;
    Global.Constant.shouldGoInGame = true;
    Global.Constant.loginTimer = setInterval(() => {
        Global.Constant.loginTime++;

        if( Global.Constant.loginTime > Global.Constant.timeOutTime ) { // 超时
     
            Global.Constant.loginTime = 0;
            Global.Constant.shouldGoInGame = false;
            if( Global.xhr ) {
                // Global.xhr.abort();
            }
            Global.DialogManager.showCommonDialog("CommenTipDialog","登录超时,请检查网络");
            Global.DialogManager.removeLoading();
            if(loginNode) loginNode.active = true;
            if(Global.Constant.loginTimer) {
                clearInterval( Global.Constant.loginTimer );
            }  
        };
    },Global.Constant.everyTime);
    // 登录计时器
}
exp.entryGameFun = function( data, node ,entryData,str) {


    Global.API.hall.entry( data , (resData) => {
        // 连接到大厅
        cc.log("off io-error");
        pomelo.off("io-error");
        switch(str){
            case "weChat":
                Global.CCHelper.clickMD("weChatTimes");
                break;
            case "account":
                Global.CCHelper.clickMD("accountTimes");
                break;  
            case "visitor":
                Global.CCHelper.clickMD("visitorTimes");
                break;          
        }
        let msg = entryData;
        // msg = auth.getDAES(msg).msg;
        // if(CC_DEBUG) cc.log(msg);

        if( cc.sys.isNative && msg.isNewUser == 1) { // 新用户注册
            openinstall.reportRegister();
        }

        Global.userInfo = msg.userInfo;
        Global.gameTypes = msg.gameTypes;
        Global.bankLists = msg.bankLists;
        Global.gameTypesMap = {};

        if(Object.prototype.toString.call(msg.gameTypes)=='[object Array]'){
            for(let game of msg.gameTypes){
                Global.gameTypesMap[game.kind] = game;
            }
        }
        // //玩家数据初始化
        Global.Player.init(msg.userInfo);
        Global.Player.gold = Number(Global.Player.gold).toFixed2(2);
        
        if(!Global.myDisconnect) {
            // Global.Player.isNewUser = msg.isNewUser;
            cc.sys.localStorage.setItem('isNewUser', msg.isNewUser); // 记录token

        }
        Global.Player.isReadGongGao = false;
        Global.Player.notReadMails = msg.notReadMails;
        Global.Player.kindId = Global.Enum.gameType.NN;
        Global.publicParaeter = msg.publicParaeter;
        cc.sys.localStorage.setItem('token', Global.Player.token); // 记录token
        if( Global.publicParaeter.spreaderUrl.indexOf("?") != -1) { // 有问号
            Global.publicParaeter.spreaderUrl = Global.publicParaeter.spreaderUrl + "&id=" + Global.Player.uid;
        } else { // 没有问号
            Global.publicParaeter.spreaderUrl = Global.publicParaeter.spreaderUrl + "?id=" + Global.Player.uid;
        }
        Global.Player.subGameConfig = msg.gameTypes; // 子游戏皮配置列表
        if(CC_DEBUG) cc.log('ajax登录成功');
        // 连如大厅
        // cc.log(Global.myDisconnect)
         if(Global.myDisconnect) { // 重连成功
            if( Global.myDisconnectTimer ) clearTimeout(Global.myDisconnectTimer); // 清除延时器
            Global.DialogManager.removeLoading();
            if(Global.subGameInfo.isInGame) { // 子游戏里了连接成功
                 Global.MessageCallback.emitMessage("ReConnectSuccess");
                
            } else { // 大厅连接成功

            }
            if(CC_DEBUG) cc.log("重连成功");
            
         } else { // 登录成功
            if(CC_DEBUG) cc.log("登录成功");
             Global.HallHasOpenActive = false;
             Global.CCHelper.bindJPushID(Global.Player.uid);
             Global.NetworkLogic.init(); // 初始化网络

             if( Global.Player.roomId && Global.Player.gameKind && Global.CCHelper.checkIsDownGame(Global.Player.gameKind) ) { // 在游戏中

                let pNode = cc.find("Canvas") || cc.find("game");
                let target = pNode.getChildByName("LoadingDialog");
                if(target) {
                   target.getComponent("LoadingDialog").init("进入游戏...");
                }
                let data = {
                    kind: Global.Player.gameKind,
                };

                Global.CCHelper.entrySubgame(data, true);



             } else {

                 let pNode = cc.find("Canvas") || cc.find("game");
                 let target = pNode.getChildByName("LoadingDialog");
                 if(target) {
                    target.getComponent("LoadingDialog").init("正在进入游戏...");
                 }
                 Global.isShowShareRedPoint = true;
                 cc.director.loadScene("HallScence");
                 cc.sys.garbageCollect();

             }
            
         }

        // 初始化重连数据
         Global.isManualLoginOut = false;  
         Global.myDisconnect = false;
        // 初始化重连数据
        // pomelo.disconnect();
    },(res) => {
        if (Global.myDisconnect) { // 断线重连失败

        } else { // 登录失败
            Global.DialogManager.removeLoading();
            Global.DialogManager.showCommonDialog("CommenTipDialog","登录失败");
            // if(CC_DEBUG) cc.log(err)
            if(CC_DEBUG) cc.log('loginDialog登录失败')
            Global.DialogManager.showCommonDialog("CommenTipDialog","登录超时，请检查您的网络连接");
            cc.sys.localStorage.setItem("token", "");
            if( node ) node.active = true;
        }
    })
}

exp.loginGameFun = function( data ,node,str) { 
    Global.DialogManager.showCommonDialog("LoadingDialog", "正在请求数据....");
    // cc.sys.localStorage.setItem("loginTimeStart", new Date().getTime());


    data.jid = Global.CCHelper.getJPushID();
    if(CC_DEBUG) cc.log(JSON.stringify(data) + "参数");

    if( !Global.myDisconnect ) { // 不是重连

        Global.CCHelper.loginResetAddressTime = false;
        pomelo.on("io-error",(res) => {
            if( Global.myDisconnect ) return;
            if( Global.Constant.relase !== "onlinePublick" || Global.CCHelper.loginResetAddressTime) {
                if( node ) node.active = true;
                Global.DialogManager.removeLoading();
                Global.DialogManager.showCommonDialog("CommenTipDialog","登录失败");
                cc.sys.localStorage.setItem("token", "");
                return;
            }
            let portArr = []; 
            let portIndex = Math.floor(Math.random() * 3);
            Global.CCHelper.loginResetAddressTime = true;
            pomelo.init( {host:"", port:portArr[portIndex]}, (res) => {
                Global.CCHelper.getIpLogin( data,node );
            });

        });
    };
 
    cc.log(Global.Constant.gameServerAddress)
   
    pomelo.init( Global.Constant.gameServerAddress, (res) => {
        Global.CCHelper.getIpLogin( data,node,str );
    });

}

exp.getIpLogin = function(data,node,str){
    Global.API.hall.getLoginIp({},(res) => {
        data.ip = res.msg;
        Global.API.hall.loginlogin( data, (Res) => {
            Global.leveUp = Res.msg.userInfo.vipLv;
            let entryData = {};
            entryData.token = Res.msg.userInfo.token;
            entryData.reconnect = data.reconnect;
            Global.CCHelper.entryGameFun( entryData, node ,Res.msg,str);
        }, (res) =>{
        	cc.log(res);
        	if(res.code != 224) Global.DialogManager.showCommonDialog("CommenTipDialog","登录失败");
            Global.DialogManager.removeLoading();
            
            cc.sys.localStorage.setItem("token","");
            if(node) node.active = true;
        })
    },(res) => {
        Global.DialogManager.removeLoading();
        Global.DialogManager.showCommonDialog("CommenTipDialog","登录失败");
        cc.sys.localStorage.setItem("token","");
        if(node) node.active = true;
    })

}
exp.checkIsDownGame = function(gameID) {
        let hasSubGameDown = false;
        let gameArr = Global.Enum.gameArr;
        for( let i = 0; i < gameArr.length; i++) {
            if( gameArr[i].kind == gameID) {
                hasSubGameDown = gameArr[i].hasDown;
                break;
            }
        }

    return hasSubGameDown;
}
// 进入子游戏
exp.entrySubgame = function(data, isInGamming = false) {
    if(CC_DEBUG) cc.log(data);
    if(Global.Player.tiren) return;
    Global.Player.gameTypeID = data._id;
    Global.Player.level = data.level;
    // Global.Player.baseScore = data.baseScore;
    let gameName = Global.Enum.gameEnglishName[data.kind];
    if(CC_DEBUG) cc.log(gameName)
    cc.sys.garbageCollect();



    if (cc.sys.OS_IOS == cc.sys.os) { // ios 设置真素问题， 当为ios 设置30贞， 当为安卓时设置60贞，这样可以优化大厅发热问题
        // cc.game.setFrameRate( 30 );
    } else {  // 这个为安卓机型的，问题
        if(gameName === Global.Enum.gameEnglishName[70]) {
            // cc.game.setFrameRate( 30 );
        } else {
            cc.game.setFrameRate( 60 );
        }
        
    }
    // Global.DialogManager.showCommonDialog("LoadingDialog", "正在进入游戏...");
    // SubgameManager.enterSubgame( gameName );
    if(cc.sys.isNative) {
        Global.DialogManager.showCommonDialog("LoadingDialog", "正在进入游戏...");
        if( gameName === Global.Enum.gameEnglishName[70] || gameName === Global.Enum.gameEnglishName[1]) {
             cc.director.loadScene( gameName,function(){
                
            });
        } else {
            SubgameManager.enterSubgame( gameName );
        }
        
    } else {
             cc.director.loadScene(gameName,function(){
                
            });
        
    }



    if(!Global.subGameInfo) {
      Global.subGameInfo = {};
    }
    Global.Player.maxChepIn = data.maxChepIn;
    Global.subGameInfo.isInGame = true;
    Global.subGameInfo.gameName = gameName;
    Global.subGameInfo.kind = data.kind;
    Global.AudioManager.stopBgMusic();
    Global.DialogManager.createdDialogs = {};
    Global.firstComeToGame = true;
    
};


exp.reconnect = function() {

    


    let token = cc.sys.localStorage.getItem('token');

    let loginData = {
        type: Global.Enum.loginType.token,
        token: token,  // 用户token
        osType: Global.DeviceInfo.osType,    // 类型【1-安卓，2-ios，3-pc】
        reconnect: true
    };



     Global.myDisconnectNumber++;
     // cc.log(Global.myDisconnectNumber)
     if( Global.myDisconnectNumber > 20) {
         Global.DialogManager.removeLoading();
          // 初始化重连数据
         Global.isManualLoginOut = true;  
         Global.myDisconnect = false;
         pomelo.disconnect();
         // 初始化重连数据
        if( Global.myDisconnectTimer ) clearTimeout(Global.myDisconnectTimer); // 清除延时器
        Global.DialogManager.showCommonDialog("PopDialog", "重连失败，请返回登录页面", function() {
            cc.sys.localStorage.setItem('token', '');

            if( !Global.subGameInfo.isInGame ) { // 没有在子游戏里返回登录
                Global.AudioManager.stopBgMusic(); // 停止背景音乐
                Global.DialogManager.destroyAllDialog();
                cc.director.loadScene("LoginScence");
            } else { // 在子游戏里
                
                this.backHall("login"); // 游戏返回登录

            }

        }.bind(this), true);
        return;
     }
     this.loginGameFun(loginData);   
}



// 返回大厅
exp.backHall = function(params = null,cb = null,boss = false) {
    Global.Player.setPy('roomId', null);
    if(Global.Player.tiren && !boss)return;
    if(CC_DEBUG) cc.log("TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT");
    Global.isManualLoginOut = true;
    Global.subGameBackTo = params || "hall";
    cc.audioEngine.stopAll();
    
    cc.sys.garbageCollect();
    if( Global.subGameBackTo == "hall") {
        
        if(window.chargeSetting){
              cc.AssetLibrary.init({
                  libraryPath: 'res/import',
                  rawAssetsBase: 'res/raw-',
                  rawAssets: window.chargeSetting.rawAssets,
                  packedAssets: window.chargeSetting.packedAssets,
                  md5AssetsMap: window.chargeSetting.md5AssetsMap
              });
            cc.director.loadScene("HallScence",function(){
                if(cb)cb();
            });
        } else {
            cc.director.loadScene("HallScence",function(){
                if(cb)cb();
            });
        } 
    } else { // 回到登录
        
        if(window.chargeSetting){
              cc.AssetLibrary.init({
                  libraryPath: 'res/import',
                  rawAssetsBase: 'res/raw-',
                  rawAssets: window.chargeSetting.rawAssets,
                  packedAssets: window.chargeSetting.packedAssets,
                  md5AssetsMap: window.chargeSetting.md5AssetsMap
              });
            cc.director.loadScene("LoginScence");
        } else {
            cc.director.loadScene("LoginScence");
        }
    }
   




}


// 加载龙骨动画
exp.loadDragonBones = function(animationDisplay, path, armatureName, newAnimation, completeCallback, playTimes = 1) {  //动态加载龙骨
       // cc.log("ccccccccccccccccccccccccc")
       // return;
        // if(newAnimation === "ani_10") return;
        animationDisplay.armatureName = newAnimation;
        // animationDisplay.animationName = newAnimation;
        animationDisplay.playAnimation(newAnimation, playTimes);
        // Global.animationDisplay.push(animationDisplay);
        return;


        cc.loader.loadResDir(path, function(err, assets){
            if(CC_DEBUG) cc.log(assets)
            if(err || assets.length <= 0)  return;
            assets.forEach(asset => {
                if(asset instanceof dragonBones.DragonBonesAsset){
                    animationDisplay.dragonAsset = asset;
                }
                if(asset instanceof dragonBones.DragonBonesAtlasAsset){
                    animationDisplay.dragonAtlasAsset  = asset;
                }
            });

            animationDisplay.armatureName = armatureName;
            animationDisplay.playAnimation(newAnimation, playTimes);
            // animationDisplay.addEventListener(dragonBones.EventObject.COMPLETE, completeCallback);
        })
}


exp.getStringRealLength = function(str) {
    let realLength = 0;
    for(let i = 0; i < str.length; ++i) {
        let count = str.charCodeAt(i);
        if(count >= 0 && count <= 128) {
            ++ realLength;
        } else {
            realLength += 2;
        }
    }
    return realLength;
};

// 截取英文字符的长度
exp.getStringByRealLength = function(str, length) {
    let realLength = 0;
    let i = 0;
    for(i = 0; i < str.length; ++i) {
        let count = str.charCodeAt(i);
        if(count >= 0 && count <= 128) {
            ++ realLength;
        } else {
            realLength += 2;
        }
        if(realLength >= length) {
            break;
        }
    }
    return str.substring(0, i+1);
};


exp.QRCreate = function(node, url) {
        let ctx = node.addComponent(cc.Graphics);
        let qrcode = new QRCode(-1, QRErrorCorrectLevel.H);
        qrcode.addData(url);
        qrcode.make();

        ctx.fillColor = cc.Color.BLACK;
        //块宽高
        let tileW = node.width / qrcode.getModuleCount();
        let tileH = node.height / qrcode.getModuleCount();

        // draw in the Graphics
        for (let row = 0; row < qrcode.getModuleCount(); row++) {
            for (let col = 0; col < qrcode.getModuleCount(); col++) {
                if (qrcode.isDark(row, col)) {
                    // ctx.fillColor = cc.Color.BLACK;
                    let w = (Math.ceil((col + 1) * tileW) - Math.floor(col * tileW));
                    let h = (Math.ceil((row + 1) * tileW) - Math.floor(row * tileW));
                    ctx.rect(Math.round(col * tileW), Math.round(row * tileH), w, h);
                    ctx.fill();
                }
            }
        }
    }
exp.getNetPort = function( cb, cbFail ) {
    let MyParams = { // 0 停服
        type: 'serverStatus',
        test: Global.CCHelper.getDeviceID().ID
    };
    // cc.log(MyParams)
    let params = {};

    let authParams = auth.getEAES( JSON.stringify(MyParams) );
    authParams.sign = encodeURIComponent(authParams.sign);
    params.data = authParams;
    params.url = Global.Constant.tingfuAddress + "/api/status";
    if(CC_DEBUG) cc.log(params)
    let urlStr = params.url;
    let methodStr = "POST";
    let responseType = params.responseType || 'json';


    var xhr = null;
    if(window.XMLHttpRequest) { // 请求对象
           xhr = new XMLHttpRequest();
    } else {
            xhr = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xhr.responseType = responseType;
    xhr.onload = function () {
        if(responseType === "json"){
            if(CC_DEBUG) cc.log(xhr.response)
          
        } else {
            if(CC_DEBUG) cc.log('收到数据2:',xhr.responseText);
        }
        if (xhr.status === 200){ // 成功
            cb( xhr.response )
        } else { // 请求数据失败
            cc.error("请求失败：status=" + xhr.status);
            let data = {
                myCode:1,
                msg: "请求失败"
            }
            cbFail( data );
            Global.DialogManager.removeLoading(); // ---------------------------------------
            
        }
    };
      xhr.onerror = function(e) { // "无网络请求失败
        let data = {
            myCode:1,
            msg: "无网络"
        }
        cbFail( data );
        Global.DialogManager.removeLoading(); // ----------
        // if(CC_DEBUG) cc.log(e);
    }
    xhr.timeout = 20000;
    xhr.ontimeout = function (e) { // XMLHttpRequest 超时。在此做某事。
        let data = {
            myCode:1,
            msg: "请求超时"
        }
        cbFail( data );
        cc.error("请求超时:", JSON.stringify(xhr.response));
        Global.DialogManager.removeLoading(); // -------------------------------

    };
    xhr.open(methodStr, urlStr, true);
    xhr.setRequestHeader("CONTENT-TYPE", "application/x-www-form-urlencoded");
    if (!!params.data) {
        let data = "";
        for (let key in params.data){
            if (params.data.hasOwnProperty(key)){
                if (data.length > 0){
                    data += "&";
                }
                data += (key + "=" + params.data[key]);
            }
        }
        if(data.length > 0){
            
            xhr.send(data);
        }else{
            
            xhr.send();
        }
    } else {
        
        xhr.send();
        
    }
}
exp.reTryWangGuan = function( cb, node, showLoading, tip ) {
    if( node ) {
        node.getComponent("WangGuanTip").init( tip ,function() {
            if( showLoading ) Global.DialogManager.showCommonDialog("LoadingDialog", "正在请求数据....");
            setTimeout(() => {
                Global.CCHelper.getTingFuGongGao(cb, node, showLoading);
            },300);
        })
    } else {
         Global.DialogManager.showCommonDialog("PopDialog", tip , function() {
             if( showLoading ) Global.DialogManager.showCommonDialog("LoadingDialog", "正在请求数据....");
             setTimeout(() => {
                 Global.CCHelper.getTingFuGongGao(cb, node, showLoading);
             },300);
         }, 4); 
    };
    Global.DialogManager.removeLoading();
}
exp.getTingFuGongGao = function(cb , node, showLoading = false ) {
    // cc.log("cccccccccccccccccccccccccccccc");
    // cc.log(showLoading)
    
    Global.CCHelper.getNetPort(function(res) {

        if(res.code === 0 ) { //网关通过
            cb( res );
        } else if( res.code === -1) { // 验签失败
            let tip = "网络请求失败（2）";
            Global.CCHelper.reTryWangGuan( cb, node, showLoading, tip );
            // if( node ) {
            //     node.getComponent("WangGuanTip").init( tip ,function() {
            //         setTimeout(() => {
            //             Global.CCHelper.getTingFuGongGao(cb, node, showLoading);
            //         },300);
            //     })
            // } else {
            //      Global.DialogManager.showCommonDialog("PopDialog", tip , function() {
            //          setTimeout(() => {
            //              Global.CCHelper.getTingFuGongGao(cb, node, showLoading);
            //          },300);
            //      }, 4); 
            // }
           
            // Global.DialogManager.removeLoading(); // ---------------------------------------
        } else if( res.code === 1) { // 时间不对，链接超时
            let tip = "网络请求失败（1）";
            Global.CCHelper.reTryWangGuan( cb, node, showLoading, tip );
            // if( node ) {
            //     node.getComponent("WangGuanTip").init( tip ,function() {
            //         setTimeout(() => {
            //             Global.CCHelper.getTingFuGongGao(cb, node, showLoading);
            //         },300);
            //     })
            // } else {
            //      Global.DialogManager.showCommonDialog("PopDialog", tip , function() {
            //          setTimeout(() => {
            //              Global.CCHelper.getTingFuGongGao(cb, node, showLoading);
            //          },300);
            //      }, 4); 
            // }
            // Global.DialogManager.removeLoading(); // ---------------------------------------
        };
        
    }, function( res) { // 请求数据错误，请检查忘我
        if(res.myCode) {
            // 错误信息 res.msg
            let tip = "网关请求失败，请点击重新尝试";
            if( Global.Constant.tingfuAddressBeiYong.length > 0 ) Global.Constant.tingfuAddress = Global.Constant.tingfuAddressBeiYong.shift();

            
            Global.CCHelper.reTryWangGuan( cb, node, showLoading, tip );
            
            // if( node ) {
            //     node.getComponent("WangGuanTip").init( tip ,function() {
            //         setTimeout(() => {
            //             Global.CCHelper.getTingFuGongGao(cb, node, showLoading);
            //         },300);
            //     })
            // } else {
            //      Global.DialogManager.showCommonDialog("PopDialog", tip , function() {
            //          setTimeout(() => {
            //              Global.CCHelper.getTingFuGongGao(cb, node, showLoading);
            //          },300)
            //      }, 4); 
            // }

        }

    });
}

exp.regPhone = /^[1][0-9]{10}$/;
exp.tingfutingren = function() {
    Global.Player.tiren = true;
    Global.DialogManager.showCommonDialog("PopDialog", "系统开始维护，玩家需要强制下线，对您造成的不便敬请谅解。", function() {
        cc.sys.localStorage.setItem('token', '');
        Global.isManualLoginOut = true;
        pomelo.disconnect();
        Global.firstComeToGame = false;

        if(!Global.subGameInfo.isInGame) { // 没有在子游戏里
            cc.audioEngine.stopAll();
            Global.DialogManager.destroyAllDialog();
            cc.director.loadScene("LoginScence");
        } else {
            Global.CCHelper.backHall("login",null,true);
        }
        
    }, true); 
}

exp.shouldBindAliPayAndBankCaed = function( bankNode, aliPayNode ,tag ) { // 显示隐藏绑定按钮
    Global.DialogManager.showCommonDialog("LoadingDialog", "正在请求数据...");
    Global.API.hall.shouldBindAliPayAndBankCaed({},(res) => {
        // cc.log(res);
        if( res.msg.cardNumber ) bankNode.active = false;
        if( res.msg.aliPayAccount ) aliPayNode.active = false;
        if(tag) Global.Player.isShowExChangeBtn = [res.msg.cardNumber, res.msg.aliPayAccount];
        Global.DialogManager.removeLoading();
    },(res) =>{
        Global.DialogManager.removeLoading();
    });
}

exp.upLoadImg = function(url) { // 底层上传图片IOS ANDROID

    if( cc.sys.os == cc.sys.OS_IOS ){ // 苹果
          let className = 'KTTool_ios'; // 原生类
          let FunName = 'getImagelnLibrary:'; // 原生方法名getNetType
          jsb.reflection.callStaticMethod(className,FunName, url); // 调用原生静态方法

    } else if( cc.sys.os == cc.sys.OS_ANDROID ){ // 安卓

        jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "getLocalImg", "(Ljava/lang/String;)V", url); 
    } 


}
exp.getImgFile = function(imgUrl) {
    // cc.log("返回的imgUrl" + imgUrl);
    if(imgUrl) {
        
        let data = {
            content: imgUrl, //内容 
            type: 2,  //1文字 2图片  
            user_id: Global.Player.uid //玩家id
        }
        
        Global.API.hall.sendMessage(data, (res) => {
            // cc.director.loadScene("KFScence");
            // this.dealData(res.msg)
            Global.MessageCallback.emitMessage("updateUpLoadImg", res);
            
        },(res) => {

        });
    }

}
exp.GHXShowNodeFun = function(  arrNode ,bannerNode) {
    let isNewUser = parseInt( cc.sys.localStorage.getItem('isNewUser') );
    // isNewUser = 1;
    if( Global.Constant.apkName === "GHX" && isNewUser === 1 && !Global.GHXShowTimeIsOut ) { // 新手 
        arrNode.forEach((item, index) => {
            if(item) item.active = false;
        });
        if( bannerNode ) bannerNode.active = true;
        if( !Global.GHXShowTimeIsOutTier ) {
           Global.GHXShowTimeIsOutTier = setTimeout(() => {
                
               if( arrNode ) {
                   arrNode.forEach((item, index) => {
                       if(item) item.active = true;
                   });
               };
               if(bannerNode) bannerNode.active = false;
               Global.GHXShowTimeIsOut = true;
           }, 60 * 15 * 1000 ); 
        }

    } else {
        if(bannerNode) bannerNode.active = false;
    }

}
exp.GHXShowKFBtn = function( node ) {

    if( Global.Constant.apkName === "GHX" ) {
        if(Global.GHXKFBtnTimeIsOut) {
            if(node) node.active = true;
            return;
        }
        if(node) node.active = false;
        if( !Global.GHXKFBtnTimeIsOutTier ) {
           Global.GHXKFBtnTimeIsOutTier = setTimeout(() => {

               if( node ) {
                    node.active = true;
               };
               
               Global.GHXKFBtnTimeIsOut = true;
           }, 60 * 15 * 1000 ); 
    };
};
}
exp.clickMD = function(str){
    if(cc.sys.os == cc.sys.OS_IOS) {
        let className = 'KTTool'; // 原生类名
        let FunName = 'BDMDClick:'; // 原生方法名
        jsb.reflection.callStaticMethod(className,FunName,str);
    }else if(cc.sys.os == cc.sys.OS_ANDROID){
        let className = 'org/cocos2dx/javascript/AppActivity'; // 原生类
        let FunName = 'clickTestMD'; // 原生方法名
        let JavaV = '(Ljava/lang/String;)V';
        // 调用原生方法
        jsb.reflection.callStaticMethod(className,FunName,JavaV,str); // 调用原生静态方法
    }
}
