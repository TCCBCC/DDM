var networkManager = require('./NetworkManager');
var messageCallback = require('./MessageCallback');
var dialogManager = require('./DialogManager');
var constant = require('./Constant');
var utils = require('./utils');
var code = require('./code');
let auth = require("auth");
var openinstall = require("OpenInstall");
var NetworkLogic = module.exports;

NetworkLogic.isManualCloseServerConnection = false;

NetworkLogic.init = function (){
    NetworkLogic.isManualCloseServerConnection = false;

    /// 添加事件监听
    messageCallback.addListener('ServerDisconnection', this);
    messageCallback.addListener('ServerMessagePush', this);
    messageCallback.addListener('PopDialogContentPush', this);
    messageCallback.addListener('kickUser', this);
    messageCallback.addListener('rechargeSuccess', this);
    messageCallback.addListener('hallPushMessage', this);
    messageCallback.addListener('kickByOther', this); //用户被挤掉
    messageCallback.addListener('updateTast', this); //任务更新
    messageCallback.addListener('gmRechargeSuccess', this); //GM金币推送
    messageCallback.addListener('closeGame', this); //游戏关闭


    networkManager.removeAllListeners();
    /// 服务器推送消息监听
    networkManager.addReceiveListen("pushBroadcast", "pushBroadcast"); // 广播消息推送
    networkManager.addReceiveListen("kickUser", "kickUser"); // 监听用户被踢掉
    networkManager.addReceiveListen("rechargeSuccess", "rechargeSuccess"); // 监听充值成功
    networkManager.addReceiveListen("hallPushMessage", "hallPushMessage"); // 邮件推送
    networkManager.addReceiveListen("kickByOther", "kickByOther"); // 其他用户踢掉
    networkManager.addReceiveListen('close', 'ServerDisconnection');
    networkManager.addReceiveListen('ServerMessagePush', 'ServerMessagePush');
    networkManager.addReceiveListen('updateTast', 'updateTast'); // 任务更新

    networkManager.addReceiveListen('gmRechargeSuccess', 'gmRechargeSuccess'); // GM金币推送
    networkManager.addReceiveListen('closeGame', 'closeGame'); // 游戏关闭
};

NetworkLogic.deInit = function () {
    /// 添加事件监听
    messageCallback.removeListener('ServerDisconnection', this);
    messageCallback.removeListener('ServerMessagePush', this);
    messageCallback.removeListener('PopDialogContentPush', this);
    messageCallback.removeListener('kickUsers', this);
    messageCallback.removeListener('rechargeSuccess', this);
    messageCallback.removeListener('kickByOther', this);
    messageCallback.removeListener('hallPushMessage', this);
    messageCallback.removeListener('updateTast', this);
    messageCallback.removeListener('gmRechargeSuccess', this); //GM金币推送
    messageCallback.removeListener('closeGame', this); //游戏关闭
};

NetworkLogic.connectToServer = function (host, port, cb){
    networkManager.init({
        host: host,
        port: port
    }, cb);
};

NetworkLogic.disconnect = function (autoReconnect){
    NetworkLogic.isManualCloseServerConnection = !autoReconnect;
    networkManager.disconnect();
};

NetworkLogic.login = function (data, cbSuccess, cbFail) { // && Global.Constant.relase == "onlinePublick"
    Global.API.account.login( data, function (data) { // ajax登录成功

            let msg = data.msg;
            msg = auth.getDAES(msg).msg;
            if(CC_DEBUG) cc.log(msg);

            if( cc.sys.isNative && msg.isNewUser == 1) { // 新用户注册
                openinstall.reportRegister();
            }

            Global.userInfo = msg.userInfo;
            Global.gameTypes = msg.gameTypes;
            Global.bankLists = msg.bankLists;
            Global.gameTypesMap = {};

            if(Object.prototype.toString.call(msg.gameTypes)=='[object Array]'){
                for(let game of msg.gameTypes){
                    Global.gameTypesMap[game.kind] = game;
                }
            }



            // //玩家数据初始化
            Global.Player.init(msg.userInfo);
            Global.Player.gold = Number(Global.Player.gold).toFixed2(2);
            Global.Player.isReadGongGao = false;
            Global.Player.notReadMails = msg.notReadMails;
            Global.Player.kindId = Global.Enum.gameType.NN;
            Global.publicParaeter = msg.publicParaeter;

            if( Global.publicParaeter.spreaderUrl.indexOf("?") != -1) { // 有问号
                Global.publicParaeter.spreaderUrl = Global.publicParaeter.spreaderUrl + "&u=" + Global.Player.uid;
            } else { // 没有问号
                Global.publicParaeter.spreaderUrl = Global.publicParaeter.spreaderUrl + "?u=" + Global.Player.uid;
            }

            


            Global.Player.subGameConfig = msg.gameTypes; // 子游戏皮配置列表
            if(CC_DEBUG) cc.log(msg)
            if(CC_DEBUG) cc.log('ajax登录成功')
            pomelo.disconnect();
            NetworkLogic.connectToServer(msg.connector.host, msg.connector.port, function () { // 进行长连任务
                
                NetworkLogic.loginHall({token: msg.userInfo.token}, cbSuccess);
            })
        }, function(data) {
            if(data && data.code == 9999 && Global.Constant.relase == "onlinePublick") { // 超时

                
                Global.Constant.gameServerAddress = "";
                Global.API.account.login( data, function (data) { // ajax登录成功

                        let msg = data.msg;
                        msg = auth.getDAES(msg).msg;
                        if(CC_DEBUG) cc.log(msg);

                        if( cc.sys.isNative && msg.isNewUser == 1) { // 新用户注册
                            openinstall.reportRegister();
                        }

                        Global.userInfo = msg.userInfo;
                        Global.gameTypes = msg.gameTypes;
                        Global.bankLists = msg.bankLists;
                        Global.gameTypesMap = {};

                        if(Object.prototype.toString.call(msg.gameTypes)=='[object Array]'){
                            for(let game of msg.gameTypes){
                                Global.gameTypesMap[game.kind] = game;
                            }
                        }



                        // //玩家数据初始化
                        Global.Player.init(msg.userInfo);
                        Global.Player.gold = Number(Global.Player.gold).toFixed2(2);
                        Global.Player.isReadGongGao = false;
                        Global.Player.notReadMails = msg.notReadMails;
                        Global.Player.kindId = Global.Enum.gameType.NN;
                        Global.publicParaeter = msg.publicParaeter;

                        if( Global.publicParaeter.spreaderUrl.indexOf("?") != -1) { // 有问号
                            Global.publicParaeter.spreaderUrl = Global.publicParaeter.spreaderUrl + "&u=" + Global.Player.uid;
                        } else { // 没有问号
                            Global.publicParaeter.spreaderUrl = Global.publicParaeter.spreaderUrl + "?u=" + Global.Player.uid;
                        }

                        


                        Global.Player.subGameConfig = msg.gameTypes; // 子游戏皮配置列表
                        if(CC_DEBUG) cc.log(msg)
                        if(CC_DEBUG) cc.log('ajax登录成功')
                        pomelo.disconnect();
                        // 登录成功
                        NetworkLogic.connectToServer(msg.connector.host, msg.connector.port, function () { // 进行长连任务
                            
                            NetworkLogic.loginHall({token: msg.userInfo.token}, cbSuccess);
                        })
                    },cbFail())
            } else {

                cbFail();
            }
            
        }
        
    );
};

NetworkLogic.register = function (data, userInfo, cbSuccess, cbFail) {
    Global.API.account.register(data.account, data.password, data.loginPlatform, data.smsCode,
        function (data) {
            // 登录成功

            NetworkLogic.connectToServer(data.msg.serverInfo.host, data.msg.serverInfo.port, function () {
                NetworkLogic.loginHall(data.msg.token, userInfo, cbSuccess);
            })
        },
        cbFail
    );
};

NetworkLogic.loginHall = function (data, cbSuccess) {

        Global.API.hall.entry(data, function (data) { // 连接大厅成功
            cc.sys.localStorage.setItem('token', Global.Player.token); // 记录token
            if(CC_DEBUG) cc.log("连接大厅成功")
            //游戏数据初始化
            // Global.Data.init(data.msg.publicParameter);
            // //玩家数据初始化
            // Global.Player.init(data.msg.userInfo);
            // //游戏类型数据初始化
            // Global.GameTypes.init(data.msg.gameTypes);
            // //代理数据初始化
            // Global.AgentProfit.init(data.msg.agentProfit);

            // Global.DialogManager.removeLoadingCircle();

            utils.invokeCallback(cbSuccess, data);

            // Global.MessageCallback.emitMessage('ReConnectSuccess');
        }, function () {
            // 进入大厅失败，断开服务器
            // cc.log("dfdfdcccccccccccccccccccccccccccccbbbbbbbb")
            Global.DialogManager.removeLoading();
            Global.NetworkLogic.disconnect(false);
            Global.DialogManager.showCommonDialog("CommenTipDialog","进入大厅失败");
        })
    

};

NetworkLogic.reconnection = function (cb) {
    let account = cc.sys.localStorage.getItem('account');
    let password = cc.sys.localStorage.getItem('password');
    let loginPlatform = parseInt(cc.sys.localStorage.getItem('platform'));
    if (!account || !password || !loginPlatform){
        dialogManager.addTip("与服务器断开连接，请重新登录", function(){
            cc.game.restart();
        });
    }else{
        NetworkLogic.login({
            account: account,
            password: password,
            loginPlatform: loginPlatform
        }, function (data) {
            utils.invokeCallback(cb, data);
        }, function () {
            utils.invokeCallback(cb, {code: 1});
        });
    }
};

NetworkLogic.messageCallbackHandler = function (router, data) {
    if (router === 'PopDialogContentPush') {
        if (!!Global.Code[data.code]) {
            Global.DialogManager.showCommonDialog('CommenTipDialog', Global.Code[data.code]);
        } else {
            Global.DialogManager.showCommonDialog('CommenTipDialog', '游戏错误，错误码：' + data.code);
        }
    } else if (router === 'PopDialogTextPush'){
        Global.DialogManager.showCommonDialog('CommenTipDialog', data.text);
    } else if (router === 'ServerMessagePush'){
        if (!data.pushRouter){
            if(CC_DEBUG) console.error('ServerMessagePush push router is invalid:'+ data);
            return;
        }
        messageCallback.emitMessage(data.pushRouter, data);
    } else if (router === 'ServerDisconnection'){ // 断线监听
         if(CC_DEBUG) cc.log("与服务器断开连接，请重新登录")
           // 如果不是手动断开则执行断线重连
            // cc.log(Global.isManualLoginOut) 
            if( Global.isManualLoginOut ) return; // 是否手动断开连接
            Global.DialogManager.showCommonDialog("LoadingDialog", "网络质量不佳，正在重新连接...");
            if( Global.myDisconnectTimer ) clearTimeout(Global.myDisconnectTimer); // 清除延时器
            Global.myDisconnectTimer = setTimeout(() => {
                cc.log("开始执行重连")
                Global.CCHelper.reconnect();
            },1000);
            if( !Global.myDisconnect ) {
                Global.myDisconnectNumber = 0;
                Global.myDisconnect = true;
            } else {
                return;
            }
            // if( Global.myDisconnectTimer ) clearTimeout(Global.myDisconnectTimer); // 清除延时器
            Global.MessageCallback.emitMessage("subGameClose", {}); // 子游戏断线监听触发
           

    } else if( router === "kickUser") { // 用户被踢掉了
        if(CC_DEBUG) cc.log("用户被踢掉了")
        Global.MessageCallback.emitMessage("subGameTingFu");
        
        if(data.msg.type == 1) { // 游戏维护
            Global.DialogManager.showCommonDialog("PopDialog", "子游戏开始维护，玩家需要强制返回大厅，对您造成的不便敬请谅解。", function() {
                // Global.firstComeToGame = false;
                Global.gameFixed = true;
                Global.CCHelper.backHall("hall",null,true);
                
            }, true); 
        } else { // 停服踢人
          Global.CCHelper.tingfutingren();

        }

    } else if ( router === "rechargeSuccess" ) {
        if(CC_DEBUG) cc.log(data);
        if(CC_DEBUG) cc.log("充陈宫代理费地方大幅度地方的")
        if(!Global.subGameInfo.isInGame) { // 没有在子游戏里
           Global.Player.gold = Number(data.msg.gold).toFixed2(2);
           Global.DialogManager.showCommonDialog("CommenTipDialog", "您的充值已成功到账");
           Global.MessageCallback.emitMessage("updateUerInfo",Global.Player);
           Global.MessageCallback.emitMessage("updateCashTask", {});
        }

    } else if (router === "hallPushMessage") {
         // Global.Player.notReadMails = Global.Player.notReadMails + 1;
         // cc.log(data)
         Global.MessageCallback.emitMessage("updateEmail", JSON.parse(decodeURI(data.msg.data)));
    } else if (router === "kickByOther") { // 用户被挤掉了
        Global.isManualLoginOut = true;
        Global.MessageCallback.emitMessage("subGameTingFu");
        Global.DialogManager.showCommonDialog("PopDialog", "您的账户正在其他设备登录", function() {
            cc.sys.localStorage.setItem('token', '');
            Global.isManualLoginOut = true;
            Global.firstComeToGame = false;

            if(!Global.subGameInfo.isInGame) { // 没有在子游戏里
                cc.audioEngine.stopAll();
                Global.DialogManager.destroyAllDialog();
                cc.director.loadScene("LoginScence");
            } else {
                Global.CCHelper.backHall("login",null,true);
            }
            
        }, true)
    } else if( router === "updateTast") {
        Global.MessageCallback.emitMessage("UpdateTast", data);
    } else if(router === "gmRechargeSuccess") { // GM充值
        if(CC_DEBUG) cc.log("GM到账成功")
        if(!Global.subGameInfo.isInGame) { // 没有在子游戏里
            Global.Player.gold = Number(data.msg.gold).toFixed2(2);
            Global.MessageCallback.emitMessage("updateUerInfo",Global.Player);
        }

    } else if(router === "closeGame") { // 游戏关闭
        if(data.msg.type === 0) { // 停服，子游戏不监听
            
                if(!Global.subGameInfo.isInGame) { // 没有在子游戏里
                    Global.CCHelper.tingfutingren();
                }
 
        } else { // 子游戏维护
            let gameTypes = Global.gameTypes;
            for(let i = 0; i < gameTypes.length; i++) {
                if(gameTypes[i].kind == data.msg.kind) {
                    gameTypes[i].isOpen = data.msg.isOpen;
                    break;
                };
            }
            if(Object.prototype.toString.call(Global.Player.gameTypes)=='[object Array]'){
                for(let game of Global.gameTypes){
                    Global.gameTypesMap[game.kind] = game;
                }
            }
            Global.MessageCallback.emitMessage("FrontcloseGame",data);
        }

    }
};

NetworkLogic.gameServerHttpRequest = function (route, method, data, cbSuccess, cbFail, way = null) {
    let url = "";

    if( constant.gameServerAddress ) {
        url = constant.gameServerAddress.host + ":" + "" + route;
        if(url.indexOf("http") === -1) url = "http://" + url;
    }



    if( way === "operation" ) { // 外httpapi
        url = constant.payAddress + route;
    }
    if( way === "tingfu"  ) {
        url = constant.tingfuAddress + route;
    }
    
    let params = {
        url: url,
        method: method,
        data: data,
        cb: function (err, response) {
            if(response){
                if(CC_DEBUG) cc.log(response.code)
                if(CC_DEBUG) cc.log("错误码" + code[response.code])   
            }
           if(CC_DEBUG) cc.log("11111111111111111111111111111111111")
            if (!!err){
                if(Global.Constant.loginTimer) {
                    clearInterval( Global.Constant.loginTimer );
                } 
                if(CC_DEBUG) cc.log("222222222222222222222222222222222222")
                if (!!cbFail){
                    if(CC_DEBUG) cc.log("99999999999999999999999999999999999")
                    utils.invokeCallback(cbFail, null, {code: 9999});
                }else{
                    Global.DialogManager.removeLoading();
                }
            } else {
                if(CC_DEBUG) cc.log("33333333333333333333333333333333")
                if (response.code !== 0){
                    if(CC_DEBUG) cc.log("444444444444444444444444444444444444444")
                    if(Global.Constant.loginTimer) {
                        clearInterval( Global.Constant.loginTimer );
                    } 
                    if (!!cbFail){
                        if(CC_DEBUG) cc.log("66666666666666666666666666666666")
                        if(response.code == -3) {
                            
                        } else if(response.code == 9999 && Global.Constant.relase == "onlinePublick") {

                        } else if(response.code == 777) {

                        } else
                        {
                            Global.DialogManager.showCommonDialog("CommenTipDialog",code[response.code] + "");
                        }
                        
                        utils.invokeCallback(cbFail, response);
                    }else{
                        if(CC_DEBUG) cc.log("7777777777777777777777777777777777777")
                        // Global.DialogManager.removeLoadingCircle();
                        Global.DialogManager.removeLoading();

                    }
                } else { // 请求数据正确
                    if(CC_DEBUG) cc.log("8888888888888888888888888888888888")
                    utils.invokeCallback(cbSuccess, response);
                }
            }
        }
    };
    Global.CCHelper.httpRequest(params);
};