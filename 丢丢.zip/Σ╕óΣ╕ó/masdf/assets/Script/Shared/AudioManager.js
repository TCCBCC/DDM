var constant = require('./Constant');

var AudioManager = module.exports = {};

AudioManager.currentBgMusic = -1;

AudioManager.isMusicEnabled = true;
AudioManager.isSoundEnabled = true;

AudioManager.musicVolume = 1; //音乐音量
AudioManager.soundVolume = 1; //音效音量

AudioManager.commonSoundPath = {
    clickButtonSound: 'Sound/button'
};

AudioManager.commonSound = {
    clickButton: null
};
AudioManager.soundOBJ = {};

//0为静音，1为开启声音
AudioManager.init = function () {
    if(CC_DEBUG) cc.log("初始化生硬资源")
    this.setSoundOn();
    this.setMusicOn();

    //初始化开关声音
    if (cc.sys.localStorage.getItem('Music') == 0) {
        this.isMusicEnabled = false;
    } else {
        cc.sys.localStorage.setItem('Music', 1);
    }



    if (cc.sys.localStorage.getItem('Sound') == 0) {
        // this.isSoundEnabled = false;
    } else {
        cc.sys.localStorage.setItem('Sound', 1);
    }

    if (cc.sys.localStorage.getItem('SoundVolume') == 0) {
        this.isSoundEnabled = false;
    }
    //初始化音乐和音效的音量
    if (cc.sys.localStorage.getItem('MusicVolume') === null) {
        cc.sys.localStorage.setItem('MusicVolume', this.musicVolume);
        cc.sys.localStorage.setItem('SoundVolume', this.soundVolume);
    } else {
        this.musicVolume = parseFloat(cc.sys.localStorage.getItem('MusicVolume'));
        this.soundVolume = parseFloat(cc.sys.localStorage.getItem('SoundVolume'));
    }

    // this.initFrame();
    cc.loader.loadRes("HallGame/Sound/btn", cc.AudioClip, function (err, clip) {
        if (!!err){
            if(CC_DEBUG) console.error('playSound failed:' + url);
        }else{
            AudioManager.CommenBtnSound = clip;
            // cc.audioEngine.play(clip, loop, AudioManager.soundVolume);
        }
    });
    cc.loader.loadRes("HallGame/Sound/charge", cc.AudioClip, function (err, clip) {
        if (!!err){
            if(CC_DEBUG) console.error('playSound failed:' + url);
        }else{
            AudioManager.CommenChargeSound = clip;
            // cc.audioEngine.play(clip, loop, AudioManager.soundVolume);
        }
    });



};
AudioManager.initFrame = function() {
    return;
    if(cc.sys.localStorage.getItem('frame')) {
        this.setFrame( Number(cc.sys.localStorage.getItem('frame')));
    } else {
        this.setFrame( 30 );
    }
}
AudioManager.setFrame = function( num ) {
    return;
    cc.game.setFrameRate( num );
    cc.sys.localStorage.setItem('frame', num);
}

AudioManager.playCommenBtnSound = function( scale = 1) {
    if (!AudioManager.isSoundEnabled) return;
    cc.audioEngine.play(AudioManager.CommenBtnSound, false, AudioManager.soundVolume * scale);
}
AudioManager.startPlayBgMusic = function (url, cb){
    if(CC_DEBUG) cc.log('startPlayBgMusic');
    if(Global.canNotPlayAudio)return;
    if (!url) url = constant.DEFUALT_BG_MUSIC_PATH;
    AudioManager.stopBgMusic();
    cc.loader.loadRes(url, function (err, clip) {
        if (!!err){
            if(CC_DEBUG) cc.log('startPlayBgMusic failed');
            
        }else{

            AudioManager.currentBgMusic = cc.audioEngine.play(clip, true, AudioManager.isMusicEnabled? AudioManager.musicVolume * 0.5:0);
            if (!AudioManager.isMusicEnabled){
                cc.audioEngine.pause(AudioManager.currentBgMusic);
            }
        }
        if(!!cb) cb(err);
    });
};
AudioManager.startPlayBgMusic2 = function (clip, cb){
    if(Global.canNotPlayAudio)return;
    if (!clip) return;
    AudioManager.stopBgMusic();
    AudioManager.currentBgMusic = cc.audioEngine.play(clip, true, AudioManager.isMusicEnabled? AudioManager.musicVolume * 0.5:0);
    if (!AudioManager.isMusicEnabled){
        cc.audioEngine.pause(AudioManager.currentBgMusic);
    }
    if(!!cb) cb(err);
};

AudioManager.stopBgMusic = function(){
    if (this.currentBgMusic === null || this.currentBgMusic < 0) return;
    cc.audioEngine.stop(this.currentBgMusic);
    this.currentBgMusic = -1;
};

AudioManager.playSound = function(url, loop, scale = 1){
    if(CC_DEBUG) cc.log(AudioManager.isSoundEnabled)
    if(Global.canNotPlayAudio)return;
    if (!url || !AudioManager.isSoundEnabled) return;
    if (loop !== true) loop = false;
    cc.loader.loadRes(url, cc.AudioClip, function (err, clip) {
        if (!!err){
            if(CC_DEBUG) console.error('playSound failed:' + url);
        }else{
            cc.audioEngine.play(clip, loop, AudioManager.soundVolume * scale);
        }
    });
};
AudioManager.playSound2 = function(clip,loop, scale = 1){
    // cc.log(AudioManager.isSoundEnabled)
    if(Global.canNotPlayAudio)return;
    if (!clip || !AudioManager.isSoundEnabled) return;
    if (loop !== true) loop = false;
    cc.audioEngine.play(clip, loop, AudioManager.soundVolume * scale);
};
AudioManager.playHallSound = function(url, loop, scale = 1){
    if(CC_DEBUG) cc.log(AudioManager.isSoundEnabled)
    if (!AudioManager.isSoundEnabled) return;
    if(url === 'charge') {
        AudioManager.soundOBJ[url] = cc.audioEngine.play(AudioManager.CommenChargeSound, loop, AudioManager.soundVolume * scale);
        return;    
    }
    let arr = url.split("/");
    let name = arr[arr.length - 1];

    if (!url || !AudioManager.isSoundEnabled) return;
    if (loop !== true) loop = false;
    cc.loader.loadRes(url, cc.AudioClip, function (err, clip) {
        if (!!err){
            if(CC_DEBUG) console.error('playSound failed:' + url);
        }else{
            AudioManager.soundOBJ[name] = cc.audioEngine.play(clip, loop, AudioManager.soundVolume);
        }
    });
};
AudioManager.stopHallSound = function(name) {
    cc.audioEngine.stop(this.soundOBJ[name])
},

AudioManager.playCommonSoundClickButton = function (scale = 1){
    if (!AudioManager.isSoundEnabled) return;
    if (AudioManager.commonSound.clickButton !== null){
        cc.audioEngine.play(AudioManager.commonSound.clickButton, false, AudioManager.soundVolume);
    }else {
        cc.loader.loadRes(AudioManager.commonSoundPath.clickButtonSound, function (err, clip) {
            if (!!err){
                if(CC_DEBUG) cc.log("playCommonSoundClickButton failed");
            }else{
                AudioManager.commonSound.clickButton = clip;
                cc.audioEngine.play(AudioManager.commonSound.clickButton, false, AudioManager.soundVolume *scale);
            }
        });
    }
};

//Music 1为开，0为关
AudioManager.setMusicOn = function () {
    cc.sys.localStorage.setItem('Music', 1);
    cc.audioEngine.setVolume(this.currentBgMusic, 1);
    cc.audioEngine.resume(this.currentBgMusic);
    this.isMusicEnabled = true;
};

AudioManager.setMusicOff = function () {
    cc.sys.localStorage.setItem('Music', 0);
    cc.audioEngine.setVolume(this.currentBgMusic, 0);
    this.isMusicEnabled = false;
};

AudioManager.getMusicEnabled = function () {
    return this.isMusicEnabled;
};

//Sound 1为开，0为关
AudioManager.setSoundOn = function () {
    cc.sys.localStorage.setItem('Sound', 1);
    this.isSoundEnabled = true;
};

AudioManager.setSoundOff = function () {
    cc.sys.localStorage.setItem('Sound', 0);
    this.isSoundEnabled = false;
};

AudioManager.getSoundEnabled = function () {
    return this.isSoundEnabled;
};

AudioManager.setMusicVolume = function (volume) {
    this.musicVolume = parseFloat(volume.toFixed(1));
    if (this.musicVolume === parseFloat(cc.sys.localStorage.getItem('MusicVolume'))) {
    } else {
        cc.sys.localStorage.setItem('MusicVolume', this.musicVolume);
    }

    if (AudioManager.currentBgMusic >= 0){
        cc.audioEngine.setVolume(AudioManager.currentBgMusic, this.musicVolume * 0.5);
    }
};

AudioManager.getMusicVolume = function () {
    return this.musicVolume;
};

AudioManager.setSoundVolume = function (volume) {
    if(volume == 0) {
        AudioManager.isSoundEnabled = false;
    } else {
        AudioManager.isSoundEnabled = true;
    }
    this.soundVolume = parseFloat(volume.toFixed(1));
    if (this.soundVolume === parseFloat(cc.sys.localStorage.getItem('SoundVolume'))) {
    } else {
        cc.sys.localStorage.setItem('SoundVolume', this.soundVolume);
    }
};

AudioManager.getSoundVolume = function () {
    return this.soundVolume;
};
