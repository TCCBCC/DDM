let SubgameManager = require('../HotUpdate/SubgameManager');
// const MD5 = require("jsb_runtime_md5");
let auth = require("auth");
let MyTip = require("Tips");
cc.Class({
    extends: cc.Component,

    properties: {
        // tips: {
        //     type: cc.Label,
        //     default:null
        // },
        barNode: cc.Node,
        percentageLabel: cc.Label,
        manifestUrl: {
            type: cc.Asset,
            default: null
        },
        _updating: false,
        _canRetry: false,
        _storagePath: '',
        _retryFrequency: 0,
        loadingGroup: cc.Node,
        // LogoNode: cc.Node,
        LoginDialog: cc.Node,
        skip: cc.Label,
        version:cc.Label,
        WangGuanTip: cc.Node,
    },

    checkCb: function (event) {
        
        //打印状态
        let state = 0;

        //状态处理
        switch (event.getEventCode()){

            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
              
                // cc.log("未找到manifest配置文件")
                this.retryHotFun( 1 );
                cc.sys.localStorage.setItem('appHotUpdateUrl', "");
                break;

            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
               
                // cc.log("远程manifest配置文件下载失败")
                this.retryHotFun( 1 );
                cc.sys.localStorage.setItem('appHotUpdateUrl', "");
                break;

            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                cc.log("已经是最新的版本")
                // this.tips.string = "已经是最新的版本";
                //this.skip.string = "热更新检测完毕"; "开"
                // cc.log("已经是最新的版本")
                // this.percentageLabel.string = "90%";
                // this.barNode.width = this.BarNodeWidth * 0.9;
                this.setBar( 0.9 );
                this.enterGame();
                // this.getComponent('loading')._isYes = true;
                // this.getComponent('loading').loading();
                break;

            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                // this.tips.string = '发现新版本';
                if(CC_DEBUG) cc.log("发现新版本")
                Global.CCHelper.clickMD("getConfigTimes");
                // this.skip.string = "发现新版本"; "开"
                // this.loadingGroup.active = true;
                state = 1;
                break;

            default:
                return;

        }

        this._am.setEventCallback(null);
        this._checkListener = null;
        this._updating = false;
        if(state === 1){ this.hotUpdate(); }
    },
    setBar( num ) {
        this.percentageLabel.string = (num * 100).toFixed(2) + "%";
        this.loadingGroup.getComponent(cc.ProgressBar).progress = num;
        this.loadingGroup.getComponent(cc.Slider).progress = num;
    },
    updateCb: function (event) {
        var needRestart = false;
        var failed = false;
        switch (event.getEventCode())
        {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                // this.tips.string = '本地未找到配置文件';
                cc.sys.localStorage.setItem('appHotUpdateUrl', "");
                
                failed = true;
                break;
            case jsb.EventAssetsManager.UPDATE_PROGRESSION:// 下载百分比
                if(CC_DEBUG) cc.log("33333333333333333333333333333" + event.getPercent())
                // if(CC_DEBUG) cc.log("33333333333333333333333333333" + typeof(event.getPercent()));
                let Percent = event.getPercent() ? event.getPercent() : 0;

                Percent = Number(Percent) * 0.9; // 百分比
              
                this.setBar( Percent );
               


                var msg = event.getMessage();
                if (msg) {
                    //显示文件下载信息
                    // this.tips.string = 'Updated file: ' + msg;

                }
                break;
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                // this.tips.string = '下载配置文件失败';
                // if(CC_DEBUG) cc.log("下载配置文件失败");
                this.retryHotFun( 1 );
                cc.sys.localStorage.setItem('appHotUpdateUrl', "");
                failed = true;
                break;
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                // this.tips.string = '已经是最新版本';
                if(CC_DEBUG) cc.log("已经是最新版本");
                this.enterGame();
                failed = true;
                break;
            case jsb.EventAssetsManager.UPDATE_FINISHED:
                //this.tips.string = '更新成功. ' + event.getMessage();
                this.loadingGroup.active = false;
                // cc.game.restart();
                // this.enterGame();
                if(CC_DEBUG) cc.log( "更新成功")
                needRestart = true;
                break;
            case jsb.EventAssetsManager.UPDATE_FAILED:
                // this.tips.string = '更新失败. ' + event.getMessage();
                // this.panel.retryBtn.active = true;
                // if(CC_DEBUG) cc.log( "更新失败")
                
                cc.sys.localStorage.setItem('appHotUpdateUrl', "");
                this._updating = false;
                this._canRetry = true;
                break;
            case jsb.EventAssetsManager.ERROR_UPDATING:
                // this.tips.string = '更新错误: ' + event.getAssetId() + ', ' + event.getMessage();
                cc.sys.localStorage.setItem('appHotUpdateUrl', "");
                if(CC_DEBUG) cc.log( "更新错误")
                
                break;
            case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                // this.tips.string = '解压失败' + event.getMessage();
                // if(CC_DEBUG) cc.log( "解压失败");
                
                cc.sys.localStorage.setItem('appHotUpdateUrl', "");
                break;
            default:
                break;
        }

        //失败
        if (failed) {
            this._am.setEventCallback(null);
            this._updateListener = null;
            this._updating = false;
        }

        //成功
        if (needRestart) {
            this._am.setEventCallback(null);
            this._updateListener = null;
            // 准备文件的搜索路径
            var searchPaths = jsb.fileUtils.getSearchPaths();
            //加载线上的manifest配置文件
            var newPaths = this._am.getLocalManifest().getSearchPaths();
            if(CC_DEBUG) console.log(JSON.stringify(newPaths));
            Array.prototype.unshift.apply(searchPaths, newPaths);
            cc.sys.localStorage.setItem('HotUpdateSearchPaths', JSON.stringify(searchPaths));
            jsb.fileUtils.setSearchPaths(searchPaths);

            cc.audioEngine.stopAll();
            setTimeout(() => {
                // this.skip.string = "热更新完成，正在重新加载游戏"; "开"
                Global.CCHelper.clickMD("hotUpdateSuccessTimes");
                cc.game.restart();

                cc.sys.localStorage.setItem('gameRestart', "true");
                cc.sys.localStorage.setItem('isHotUpdate', "true");
            },10)
        }

        //更新失败重试

        if (this._canRetry) {
            this.retry();
        }


    },
    // 1、网络请求失败（时间异常）
    // 2、网络请求失败（认证异常）
    // 3、网络请求失败（配置异常）
    // 4、网络请求失败（更新异常）
    retryHotFun( i ) {
        let tip = i === 1 ? "网络请求失败（3）" : "网络请求失败（4）";
        this.WangGuanTip.getComponent("WangGuanTip").init( tip ,function() {
            // let newAddress = Global.Constant.BackUpHallHotUpAddress + "/hall" + Global.Constant.HallNewVersion;
            let newAddress = Global.Constant.BackUpHallHotUpAddress;
            this.node.parent.getComponent("LoginBox").modifyAppLoadUrlForManifestFile( newAddress, "1.0.00", this.manifestUrl.nativeUrl,  function(){
                setTimeout(() => {
                    this.goHotUpdataFun();
                },300);
            }.bind(this));

        }.bind(this));
    },
    
    //下载失败时重试
    retry: function () {
        if (!this._updating && this._canRetry) {

            if(this._retryFrequency >= 10) {  //下载失败，重试次数过多，请重启游戏
                this._retryFrequency = 0;
                this.retryHotFun( 2 );
                return;
            } else { this._retryFrequency += 1; }

            this._canRetry = false;            
            if(CC_DEBUG) cc.log('重试');
            this._am.downloadFailedAssets();
        }
    },
    
    //检测更新
    checkUpdate: function () {
        // this.skip.string = "正在检测更新" "开"
        this.loadingGroup.active = true;
        if (this._updating) {
            // this.tips.string = 'Checking or updating ...';
            return;
        }

        if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
            // Resolve md5 url
            var url = this.manifestUrl.nativeUrl;
            if (cc.loader.md5Pipe) {
                url = cc.loader.md5Pipe.transformURL(url);
            }
            this._am.loadLocalManifest(url);
        }
        if (!this._am.getLocalManifest() || !this._am.getLocalManifest().isLoaded()) {
            // this.tips.string = '加载本地manifest配置文件失败';
            this.retryHotFun( 1 );
            cc.sys.localStorage.setItem('appHotUpdateUrl', "");
            return;
        }
        this._am.setEventCallback(this.checkCb.bind(this));

        this._am.checkUpdate();
        this._updating = true;
    },

    hotUpdate: function () {
        if (this._am && !this._updating) {
            this._am.setEventCallback(this.updateCb.bind(this));

            if (this._am.getState() === jsb.AssetsManager.State.UNINITED) {
                // Resolve md5 url
                var url = this.manifestUrl.nativeUrl;
                if (cc.loader.md5Pipe) {
                    url = cc.loader.md5Pipe.transformURL(url);
                }
                this._am.loadLocalManifest(url);
            }

            this._failCount = 0;
            this._am.update();
            this._updating = true;
        }
    },

    onLoad: function () {
        // 检测是否为原生环境

        // this.BarNodeWidth = 768;
        this.setBar( 0 );
        this.RandomTips();



        

        
    },
    BIVersion() {
       
        return Global.Constant.HallNewVersion;
    },
    goHotUpdataFun() {
        if (cc.sys.isNative) {
            // this.enterGame();
            // 检查是否最新版
            let storagePath = ((jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + 'HXGame');
            if(CC_DEBUG) cc.log("StoragePath for remote asset : ", storagePath);
            let loadManifest = jsb.fileUtils.getStringFromFile(storagePath + '/project.manifest');
            let manifestObject = JSON.parse(loadManifest);
            let Version = manifestObject.version;
            if( Version === this.BIVersion()) {

                this.version.string = "v" + Version;
                this.enterGame(); // 子游戏检车
                return;
            }
            // 检查是否最新版
            this.init();
            // this.percentageLabel.string = "O%";
            this.checkUpdate(); // 开始检测热更新
        }  else {
            this.getTingFuGongGao();
        }
    },
    RandomTips() {
        let len = MyTip.length;
        let index = parseInt(Math.random(0,1)*len);
        this.skip.string = MyTip[index];
        this.MyTipTimer = setInterval(() => {
            let index = parseInt(Math.random(0,1)*len);
            this.skip.string = MyTip[index];
        },5000);
        

    },
    init() {
        var self = this;
        this._storagePath = ((jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + 'HXGame');
        if(CC_DEBUG) cc.log('远程资源存储路径: ' + this._storagePath);

        // 设置程序版本，版本A或者版本B，作为字符串
        // 如果返回的值大于0，那么版本A大于版本B
        // 如果返回值为0，那么版本A与版本B相同
        // 如果返回值小于0，那么版本A小于版本B
        this.versionCompareHandle = function (versionA, versionB) {
            if(CC_DEBUG) cc.log("JS Custom Version Compare: version A is " + versionA + ', version B is ' + versionB);
            if( cc.sys.localStorage.getItem('gameRestart') != "true" ) { // 不是重启游戏则记住版本号
                cc.sys.localStorage.setItem('gameVersion', versionA)
            }
            self.version.string = "v" + versionA;
            Global.VERSION = "v" + versionA;
            var vA = versionA.split('.');
            var vB = versionB.split('.');
            for (var i = 0; i < vA.length; ++i) {
                var a = parseInt(vA[i]);
                var b = parseInt(vB[i] || 0);
                if (a === b) {
                    continue;
                }
                else {
                    return a - b;
                }
            }
            if (vB.length > vA.length) {
                return -1;
            }
            else {
                return 0;
            }
        };

        // Init with empty manifest url for testing custom manifest
        this._am = new jsb.AssetsManager('', this._storagePath, this.versionCompareHandle);

        // Setup the verification callback, but we don't have md5 check function yet, so only print some message
        // Return true if the verification passed, otherwise return false
        this._am.setVerifyCallback(function (path, asset) {
            // When asset is compressed, we don't need to check its md5, because zip file have been deleted.
            var compressed = asset.compressed;
            // Retrieve the correct md5 value.
            var expectedMD5 = asset.md5;
            // asset.path is relative path and path is absolute.
            var relativePath = asset.path;
            // The size of asset file, but this value could be absent.
            // var size = asset.size;

            if(/\.plist$/.test(path)) return true;
            // var data = jsb.fileUtils.getDataFromFile(path);
            var size = jsb.fileUtils.getFileSize(path); // getFileSize
            if(CC_DEBUG) {
                cc.log(size + "L88888888888888888888888888888888888888L" + asset.size)
            }
            return asset.size == size
        }.bind(this));


        if (cc.sys.os === cc.sys.OS_ANDROID) { //一些安卓设备并行过大会出现不可预料的错误
            this._am.setMaxConcurrentTask(2); //设置并行下载任务数
        }
    },


    getTingFuGongGao() {
       
        this.setBar( 1 );
        this.LoginDialog.active = true;
        this.node.active = false;

    },
    enterGame: function () { // 进入游戏
        this.gameIndex = -1;
        this.checkSubgame(); 
    },


    checkSubgame() { // 递归检测所有子
        // this.skip.string = "子游戏检测"; "开"
        this.gameIndex = this.gameIndex + 1;




         let per = (this.gameIndex / Global.Enum.gameArr.length);

         let allPer = 0.9 + per * 0.05;
         // this.percentageLabel.string = (allPer * 100).toFixed(2) + "%";

         // this.barNode.width = this.BarNodeWidth * allPer;
         this.setBar( allPer );

        if(this.gameIndex > Global.Enum.gameArr.length - 1 || !cc.sys.isNative) {
            // this.skip.string = "子游戏检测完毕"; "开"
            this.getTingFuGongGao();

            return;
        };


        let kind = Global.Enum.gameArr[this.gameIndex].kind;

        let gameName =  Global.Enum.gameEnglishName[kind];
        if( gameName === "FISH" || gameName === "ZJH") {
            Global.Enum.gameArr[this.gameIndex].hasDown = true;
            this.checkSubgame();
            return;
        }
        let that = this;
        // return;
        SubgameManager.CustomCheckSubGame( gameName, Global.Constant.versionData, function( right ) {

             Global.Enum.gameArr[that.gameIndex].hasDown = right;
             that.checkSubgame();
        })

        // if(SubgameManager.isSubgameDownLoad(gameName)){

        //     SubgameManager.needUpdateSubgame(gameName, (success) => {
        //         if(success){ // 需要更新
        //             Global.Enum.gameArr[this.gameIndex].hasDown = false;
        //             this.checkSubgame();
        //         } else { // 已就绪
        //             Global.Enum.gameArr[this.gameIndex].hasDown = true;
        //             this.checkSubgame();
        //         }
        //     }, () => { // 检测出错
        //         Global.Enum.gameArr[this.gameIndex].hasDown = false;
        //         this.checkSubgame();
        //     });

        // } else { // 未下载

        //     Global.Enum.gameArr[this.gameIndex].hasDown = false;
        //     this.checkSubgame();

        // }
    },

    onDestroy: function () {
        if (this._updateListener) {
            this._am.setEventCallback(null);
            this._updateListener = null;
        }
        if(this.MyTipTimer) {
            clearInterval(this.MyTipTimer)
        }
    }
});
