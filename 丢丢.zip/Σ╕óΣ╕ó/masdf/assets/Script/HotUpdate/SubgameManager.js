const MD5 = require("jsb_runtime_md5");
const SubgameManager = {
    _storagePath: [],
    CustomCheckSubGame: function( gameName ,customData, cb) {
        let storagePath = ((jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + 'subGame/' + gameName );

        cc.log("StoragePath for remote asset : ", storagePath);
        let loadManifest = jsb.fileUtils.getStringFromFile(storagePath + '/project.manifest');
        // cc.log(loadManifest)
        if(!loadManifest) {
            cb(false);
            return;
        }
        let manifestObject = JSON.parse(loadManifest);
        let Version = manifestObject.version;

        if(!customData[gameName]) return false;
        if(Global.Constant.apkName === "HX") {
            if(cc.sys.os == cc.sys.OS_ANDROID) {
                    
                    cb( Version === customData[gameName].android ? true : false );

            } else if(cc.sys.os === cc.sys.OS_IOS) {

                    cb( Version === customData[gameName].ios ? true : false );
            } else {
                    cb( Version === customData[gameName].android ? true : false );
            }
        } else {
            if(cc.sys.os == cc.sys.OS_ANDROID) {
                    
                    cb( Version === customData[gameName].androidGreen ? true : false );

            } else if(cc.sys.os === cc.sys.OS_IOS) {

                    cb( Version === customData[gameName].iosGreen ? true : false );
            } else {
                    cb( Version === customData[gameName].androidGreen ? true : false );
            }
        }

        

    },
    _getfiles: function(name, type, downloadCallback, finishCallback) {
        this._storagePath[name] = ((jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + 'subGame/' + name); // 本地的存储路径
        this._downloadCallback = downloadCallback;
        this._finishCallback = finishCallback;
        this._fileName = name;

        try {
          if( jsb.fileUtils.isDirectoryExist( this._storagePath[name] + "_temp" )) {
           
            jsb.fileUtils.removeDirectory(this._storagePath[name] + "_temp/");
            // jsb.fileUtils.removeFile( this._storagePath[name] + "_temp/project.manifest.temp"  );
          }
        }catch( error ) {
         
        };
        
        

        var UIRLFILE = Global.Constant.hotUpdateAddress  + "/" + name + "/" ; //子游戏下载地址 BackUpSonHotUpAddress   hotUpdateAddress
        if( Global.Constant.subGameDownStatus[name] === 0 ) {
            UIRLFILE = Global.Constant.BackUpSonHotUpAddress  + "/" + name + "/"; //备用子游戏下载地址 
        }

        UIRLFILE = UIRLFILE + name.toLowerCase();
        if(Global.Constant.apkName === "HX") {
            if(cc.sys.os == cc.sys.OS_ANDROID) {
                    
                    // cb( Version === customData[gameName].android ? true : false );
                    UIRLFILE = UIRLFILE + Global.Constant.versionData[name].android;
            } else if(cc.sys.os === cc.sys.OS_IOS) {
                    UIRLFILE = UIRLFILE + Global.Constant.versionData[name].ios;
                    // cb( Version === customData[gameName].ios ? true : false );
            } else {
                    // cb( Version === customData[gameName].android ? true : false );
                    // JSON.stringify(Global.Constant.versionData[name])
                    UIRLFILE = UIRLFILE + Global.Constant.versionData[name].android;
            }
        } else {
            if(cc.sys.os == cc.sys.OS_ANDROID) {
                    
                    // cb( Version === customData[gameName].androidGreen ? true : false );
                    UIRLFILE = UIRLFILE + Global.Constant.versionData[name].androidGreen;

            } else if(cc.sys.os === cc.sys.OS_IOS) {
                    UIRLFILE = UIRLFILE + Global.Constant.versionData[name].iosGreen;
                    // cb( Version === customData[gameName].iosGreen ? true : false );
            } else {
                    // cb( Version === customData[gameName].androidGreen ? true : false );
                     UIRLFILE = UIRLFILE + Global.Constant.versionData[name].androidGreen;
            }
        }
        UIRLFILE = UIRLFILE + "/";
        if( Global.Constant.relase === "offLineDubug" )  {
            var UIRLFILE = Global.Constant.hotUpdateAddress  + "/" + name + "/" ; //子游戏下载地址 BackUpSonHotUpAddress   hotUpdateAddress
            if( Global.Constant.subGameDownStatus[name] === 0 ) UIRLFILE = Global.Constant.BackUpSonHotUpAddress  + "/" + name + "/"; //子游戏下载地址 
        }


        // 测试


        if(CC_DEBUG) cc.log(UIRLFILE + "下载子游戏地址")



        var filees = this._storagePath[name] + '/project.manifest';
        if(filees && jsb.fileUtils.getStringFromFile( filees )) {
           
            if(CC_DEBUG) cc.log("存储路径", this._storagePath[name]);

            let loadManifest = jsb.fileUtils.getStringFromFile( filees );
            if(CC_DEBUG) cc.log(loadManifest)
            let severAdress = UIRLFILE + "project.manifest"
            if(CC_DEBUG) cc.log( severAdress+ "服务器地址")
            let manifestObject = JSON.parse(loadManifest);
            let locallAddress = manifestObject.remoteManifestUrl;
            if(CC_DEBUG) cc.log(locallAddress + "本地地址");

            if(severAdress != locallAddress) {
                manifestObject.packageUrl = UIRLFILE ;
                manifestObject.remoteManifestUrl = UIRLFILE + 'project.manifest';
                manifestObject.remoteVersionUrl = UIRLFILE + 'version.manifest';
                
                let afterString = JSON.stringify( manifestObject );
                if(CC_DEBUG) cc.log(afterString)
                let isWritten = jsb.fileUtils.writeStringToFile( afterString, this._storagePath[name] + '/project.manifest' );
                // cc.log('333333333333333333333333')
                //更新数据库中的新请求地址，下次如果检测到不一致就重新修改 manifest 文件

                if(CC_DEBUG) cc.log("Written Status : ", isWritten);
            } else {
                if(CC_DEBUG) cc.log("路径没有改变");
            }

        } else {
            if(CC_DEBUG) cc.log("没有地址");
        }

        var customManifestStr = JSON.stringify({
            'packageUrl': UIRLFILE,
            'remoteManifestUrl': UIRLFILE + 'project.manifest',
            'remoteVersionUrl': UIRLFILE + 'version.manifest',
            'version': '0.0.0',
            'assets': {},
            'searchPaths': []
        });

        var versionCompareHandle = function(versionA, versionB) {
            var vA = versionA.split('.');
            var vB = versionB.split('.');
            for (var i = 0; i < vA.length; ++i) {
                var a = parseInt(vA[i]);
                var b = parseInt(vB[i] || 0);
                if (a === b) {
                    continue;
                } else {
                    return a - b;
                }
            }
            if (vB.length > vA.length) {
                return -1;
            } else {
                return 0;
            }
        };

        this._am = new jsb.AssetsManager('', this._storagePath[name], versionCompareHandle); // 热更新管理器

        this._am.setVerifyCallback(function(path, asset) {
            // cc.log(path);
            if(/\.plist$/.test(path)) return true;
            
            var compressed = asset.compressed;
            var size = jsb.fileUtils.getFileSize(path); // getFileSize
            if( Global.Constant.relase === "offLineDubug" ) {
                cc.log(size + "L88888888888888888888888888888888888888L" + asset.size)
                return true;

            } else {
                if(CC_DEBUG) cc.log(size + "L88888888888888888888888888888888888888L" + asset.size);
                return asset.size == size
            }

            

        }.bind(this));


        if (cc.sys.os === cc.sys.OS_ANDROID) {
            this._am.setMaxConcurrentTask(2);
        }

        if (type === 1) {
            this._am.setEventCallback(this._updateCb.bind(this));
        } else if (type == 2) {
            this._am.setEventCallback(this._checkCb.bind(this));
        } else {
            this._am.setEventCallback(this._needUpdate.bind(this));
        }

        if (this._am.getState() === jsb.AssetsManager.State.UNINITED) { // uninited
            // cc.log("没有下载的文件") // http://192.168.50.205:8181
            // cc.log(this._storagePath[name])
            // let a = jsb.fileUtils.writeStringToFile(customManifestStr, this._storagePath[name] + '/project.manifest');
            // cc.log(a)
            var manifest = new jsb.Manifest(customManifestStr, this._storagePath[name]);
            this._am.loadLocalManifest(manifest, this._storagePath[name]);
        } else {
            // cc.log("有下载的文件")
        }

        if (type === 1) {
            this._am.update();
            this._failCount = 0;
        } else {
            this._am.checkUpdate();
        }
        this._updating = true;
        // cc.log(jsb.fileUtils.getStringFromFile(filees));
        // if(CC_DEBUG) cc.log('更新文件:' + filees);
    },

    // type = 1
    calMD5OfFile:function(filePath){return MD5(jsb.fileUtils.getDataFromFile(filePath));},
    _updateCb: function(event) {
        var failed = false;
        let self = this;
        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                /*0 本地没有配置文件*/
                if(CC_DEBUG) cc.log('updateCb本地没有配置文件');
                failed = true;
                break;

            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
                /*1下载配置文件错误*/
                if(CC_DEBUG) cc.log('updateCb下载配置文件错误');
                failed = true;
                break;

            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                /*2 解析文件错误*/
                if(CC_DEBUG) cc.log('updateCb解析文件错误');
                failed = true;
                break;

            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                /*3发现新的更新*/
                if(CC_DEBUG) cc.log('updateCb发现新的更新');
                break;

            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                /*4 已经是最新的*/
                if(CC_DEBUG) cc.log('updateCb已经是最新的');
                failed = true;
                break;

            case jsb.EventAssetsManager.UPDATE_PROGRESSION:
                /*5 最新进展 */
                self._downloadCallback && self._downloadCallback(event.getPercentByFile());
                break;


            case jsb.EventAssetsManager.ASSET_UPDATED:
                /*6需要更新*/
                break;

            case jsb.EventAssetsManager.ERROR_UPDATING:
                /*7更新错误*/
                if(CC_DEBUG) cc.log('updateCb更新错误');
                break;

            case jsb.EventAssetsManager.UPDATE_FINISHED:
                /*8更新完成*/
                self._finishCallback && self._finishCallback(true);
                break;

            case jsb.EventAssetsManager.UPDATE_FAILED:
                /*9更新失败*/
                self._failCount++;
                if (self._failCount <= 3) {
                    self._am.downloadFailedAssets();
                    if(CC_DEBUG) cc.log(('updateCb更新失败' + this._failCount + ' 次'));
                } else {
                    if(CC_DEBUG) cc.log(('updateCb失败次数过多'));
                    self._failCount = 0;
                    failed = true;
                    self._updating = false;
                }
                break;

            case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                /*10解压失败*/
                if(CC_DEBUG) cc.log('updateCb解压失败');
                break;
        }

        if (failed) {
            this._am.setEventCallback(null);
            self._updateListener = null;
            self._updating = false;
            self._finishCallback && self._finishCallback(false);
        }
    },

    // type = 2
    _checkCb: function(event) {
        var failed = false;
        let self = this;
        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                /*0 本地没有配置文件*/
                if(CC_DEBUG) cc.log('checkCb本地没有配置文件');
                break;

            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
                /*1下载配置文件错误*/
                if(CC_DEBUG) cc.log('checkCb下载配置文件错误');
                failed = true;
                break;

            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                /*2 解析文件错误*/
                if(CC_DEBUG) cc.log('checkCb解析文件错误');
                failed = true;
                break;

            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                /*3发现新的更新*/
                self._getfiles(self._fileName, 1, self._downloadCallback, self._finishCallback);
                break;

            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                /*4 已经是最新的*/
                if(CC_DEBUG) cc.log('checkCb已经是最新的');
                self._finishCallback && self._finishCallback(true);

                break;

            case jsb.EventAssetsManager.UPDATE_PROGRESSION:
                /*5 最新进展 */
                break;

            case jsb.EventAssetsManager.ASSET_UPDATED:
                /*6需要更新*/
                break;

            case jsb.EventAssetsManager.ERROR_UPDATING:
                /*7更新错误*/
                if(CC_DEBUG) cc.log('checkCb更新错误');
                failed = true;
                break;


            case jsb.EventAssetsManager.UPDATE_FINISHED:
                /*8更新完成*/
                if(CC_DEBUG) cc.log('checkCb更新完成');
                break;

            case jsb.EventAssetsManager.UPDATE_FAILED:
                /*9更新失败*/
                if(CC_DEBUG) cc.log('checkCb更新失败');
                failed = true;
                break;

            case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                /*10解压失败*/
                if(CC_DEBUG) cc.log('checkCb解压失败');
                break;

        }
        this._updating = false;
        if (failed) {
            this._am.setEventCallback(null);
            self._finishCallback && self._finishCallback(false);
        }
    },

    // type = 3
    _needUpdate: function(event) {
        let self = this;
        switch (event.getEventCode()) {
            case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                if(CC_DEBUG) cc.log('子游戏已经是最新的，不需要更新');
                self._finishCallback && self._finishCallback(false);
                break;

            case jsb.EventAssetsManager.NEW_VERSION_FOUND:
                if(CC_DEBUG) cc.log('子游戏需要更新');
                self._finishCallback && self._finishCallback(true);
                break;

            // 检查是否更新出错
            case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
            case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
            case jsb.EventAssetsManager.ERROR_UPDATING:
            case jsb.EventAssetsManager.UPDATE_FAILED:
                self._downloadCallback();
                break;
        }
    },

    /**
     * 下载子游戏
     * @param {string} name - 游戏名
     * @param progress - 下载进度回调
     * @param finish - 完成回调
     * @note finish 返回true表示下载成功，false表示下载失败
     */
    downloadSubgame: function(name, progress, finish) {
        this.gameName = name;
        this._getfiles(name, 2, progress, finish);
    },

    /**
     * 进入子游戏
     * @param {string} name - 游戏名
     */
    enterSubgame: function(name) {


        this._storagePath[name] = ((jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + 'subGame/' + name);
        if (!this._storagePath[name]) {
          this.downloadSubgame(name);
          return;
        }
        cc.audioEngine.stopAll();
        try{
            _re(this._storagePath[name] + "/src/main.js");
        }catch(err){
            require(this._storagePath[name] + "/src/main.js");
        }
    },

    

    /**
     * 判断子游戏是否已经下载
     * @param {string} name - 游戏名
     */
    isSubgameDownLoad: function (name) {
        let file = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : '/') + 'subGame/' + name + '/project.manifest';
        if (jsb.fileUtils.isFileExist(file)) {
            if(CC_DEBUG) cc.log('拿到');
            return true;
        } else {
            if(CC_DEBUG) cc.log('未拿到');
            return false;
        }
    },

    /**
     * 判断子游戏是否需要更新
     * @param {string} name - 游戏名
     * @param isUpdateCallback - 是否需要更新回调
     * @param failCallback - 错误回调
     * @note isUpdateCallback 返回true表示需要更新，false表示不需要更新
     */
    needUpdateSubgame: function (name, isUpdateCallback, failCallback) {
        this._getfiles(name, 3, failCallback, isUpdateCallback);
    },
};

module.exports = SubgameManager;