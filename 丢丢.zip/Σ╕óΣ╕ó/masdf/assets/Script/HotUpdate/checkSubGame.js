let SubgameManager = require('./SubgameManager');
cc.Class({
    extends: cc.Component,

    properties: {
        tip: cc.Node,
      
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.isDown = false;
        this.nextCheck = true;
        this.gameIndex = 0;
        this.gameNum = 8; // 子游戏数量
        // if(cc.sys.isNative){
        //     this.checkFun(this);
        // }
        
    },
    checkFun(that) { // 递归检测所有子d
        // return;
        // if(!cc.sys.isNative){return;}
        if(that.gameIndex >= this.gameNum) { // 所有子游戏检测完毕
            this.LoadingNode.active = false;
            return
        };
        let node = that.node.children[that.gameIndex];
        if(SubgameManager.isSubgameDownLoad(node.name)){
            SubgameManager.needUpdateSubgame(node.name, (success) => {
                if(success){ 
                    // item.gameStatus = 3; // 需要更新
                    node.getChildByName('text').getComponent(cc.Label).string = '立即更新';
                    that.nextFun(that);
                } else { 

                    // item.gameStatus = 1; // 已就绪
                    let name = node.name;
                    node.getChildByName(name).active = false;
                    node.getChildByName('text').active = false;
                    node.getChildByName('downIcon').active = false;
                    that.nextFun(that);
                }
            }, () => { 
                // item.gameStatus = 4; // 检测出错
                node.getChildByName('text').getComponent(cc.Label).string = '检测出错';
                that.nextFun(that)
            });
        } else {
            // item.gameStatus = 2; // 未下载
            that.nextFun(that);
        }
    },

    gameDownload (e, gameName) {
        // if(!cc.sys.isNative){
        //     return;
            
        // }
        // let barWidth = 284;
        

   
   
        // let gameName = 'gameOne';
        this.isDown = true;
        let node = e.currentTarget;
        let LoadingNode = node.getChildByName("Loading");
        LoadingNode.getComponent(cc.ProgressBar).progress = 0;
        LoadingNode.active = true;
        // return;


        SubgameManager.downloadSubgame(gameName, (progress) => {
            if(isNaN(progress)){
                progress = 0;
            }
            
            LoadingNode.getComponent(cc.ProgressBar).progress = parseInt(progress * 100) +'%';
            

        }, (success) => {
            if(success){ // 下载成功
                LoadingNode.active = false;
                this.isDown = false;
                // this.tip.getComponent(cc.Label).string = "下载成功"
            } else { // 下载失败
                // this.tip.getComponent(cc.Label).string = "下载失败";
                this.isDown = false;
            }
        });
    },
    nextFun(that) {
        that.gameIndex += 1;
        that.checkFun(that)
    },
    entryGame(e, gameName) {
        if( !this.isDown ) return;
        let g = gameName;
        this.gameDownload(e, g);

    },
    start () {

    },

    // update (dt) {},
});
