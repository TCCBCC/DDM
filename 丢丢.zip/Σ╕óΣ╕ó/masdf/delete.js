
var fs = require('fs'); // 引入fs模块
// var config;
// if(process.argv[2] === "server_online"){
//   config = require("./config_server_online")
// }else if(process.argv[2] === "server"){
//   config = require("./config_server")
// }else if(process.argv[2] === "relase_local"){
//   config = require("./config_relase_local")
// }else{
//   config = require("./config")
// }
function deleteall(path) {
	var files = [];
	if(fs.existsSync(path)) {
		files = fs.readdirSync(path);
		files.forEach(function(file, index) {
			var curPath = path + "/" + file;
			if(fs.statSync(curPath).isDirectory()) { // recurse
				deleteall(curPath);
			} else { // delete file
				fs.unlinkSync(curPath);
			}
		});
		fs.rmdirSync(path);
	}
}
deleteall("D:/360MoveData/Users/abc/Desktop/mysrc/hall")