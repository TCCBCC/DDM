window.boot = function () {
    window.chargeSetting = window._CCSettings;
    var settings = window._CCSettings;
    window._CCSettings = undefined;
    window._re = require;

    if ( !settings.debug ) {
        var uuids = settings.uuids;

        var rawAssets = settings.rawAssets;
        var assetTypes = settings.assetTypes;
        var realRawAssets = settings.rawAssets = {};
        for (var mount in rawAssets) {
            var entries = rawAssets[mount];
            var realEntries = realRawAssets[mount] = {};
            for (var id in entries) {
                var entry = entries[id];
                var type = entry[1];
                // retrieve minified raw asset
                if (typeof type === 'number') {
                    entry[1] = assetTypes[type];
                }
                // retrieve uuid
                realEntries[uuids[id] || id] = entry;
            }
        }

        var scenes = settings.scenes;
        for (var i = 0; i < scenes.length; ++i) {
            var scene = scenes[i];
            if (typeof scene.uuid === 'number') {
                scene.uuid = uuids[scene.uuid];
            }
        }

        var packedAssets = settings.packedAssets;
        for (var packId in packedAssets) {
            var packedIds = packedAssets[packId];
            for (var j = 0; j < packedIds.length; ++j) {
                if (typeof packedIds[j] === 'number') {
                    packedIds[j] = uuids[packedIds[j]];
                }
            }
        }
    }

    var onStart = function () {
        // if( cc.sys.os == cc.sys.OS_IOS ) {  
        //     let className = 'KTTool_ios'; // 原生类名
        //     let FunName = 'interfaceOrientationWithOpsion:'; // 原生方法名
        //     jsb.reflection.callStaticMethod(className,FunName, 1);
        // };
        let isHotUpdate = cc.sys.localStorage.getItem('isHotUpdate');

        cc.AssetLibrary.init({
            libraryPath: 'res/import',
            rawAssetsBase: 'res/raw-',
            rawAssets: settings.rawAssets,
            packedAssets: settings.packedAssets,
            md5AssetsMap: settings.md5AssetsMap
        });

        var launchScene = settings.launchScene;

        if( isHotUpdate == "true") {

            cc.loader.downloader._subpackages = settings.subpackages;
            cc.view.enableRetina(true);
            cc.view.resizeWithBrowserSize(true);
            
            cc.director.loadScene(launchScene, null,
                function () {
                    cc.loader.onProgress = null;
                    
                    console.log('Success to load scene: ' + launchScene);
                }
            );
            return;
        } 
         
        var Lscene = new cc.Scene();


        var root = new cc.Node();

        var canvas = root.addComponent(cc.Canvas);

        root.parent = Lscene;

         

        // 2. Add sprite component

        var bgSprite = root.addComponent(cc.Sprite);

        var createImage = function (imgUrl, target_) {
            var target = target_;
            if ((imgUrl && imgUrl.indexOf('http') >= 0)) {
                cc.loader.load({url: imgUrl, type: "png"}, function (err, texture) {
                    if (!!err) {
                        cc.error(err);
                        // utils.invokeCallback(cb, err);
                    } else {
                        if (target.isValid) {
                            target.spriteFrame = new cc.SpriteFrame(texture);
                            // utils.invokeCallback(cb);
                        }
                    }
                });
                //加载本地图片
            } else {
                cc.loader.loadRes(imgUrl, cc.SpriteFrame, function (err, spriteFrame){
                    if (!!err){
                        cc.log("34444444444444444444444444444444444444")
                        cc.log(err);
                    }else{
                        cc.log("2444444444444444444444444444444444444444444")
                        if (target.isValid){
                            target.spriteFrame = spriteFrame;
                        }
                    }
                });
            }

        };

        createImage("Lanch/Lanch", bgSprite);
        cc.director.runSceneImmediate( Lscene );

        setTimeout( function() {
            cc.loader.downloader._subpackages = settings.subpackages;
            cc.view.enableRetina(true);
            cc.view.resizeWithBrowserSize(true);
            cc.sys.localStorage.setItem('isHotUpdate', "false")
            cc.director.loadScene(launchScene, null,
                function () {
                    cc.loader.onProgress = null;
                    
                    console.log('Success to load scene: ' + launchScene);
                }
            );
        },3000)




    };

    // jsList
    var jsList = settings.jsList;
    var bundledScript = settings.debug ? 'src/project.dev.js' : 'src/project.js';
    if (jsList) {
        jsList = jsList.map(function (x) {
            return 'src/' + x;
        });
        jsList.push(bundledScript);
    }
    else {
        jsList = [bundledScript];
    }

    // anysdk scripts
    if (cc.sys.isNative && cc.sys.isMobile) {
//        jsList = jsList.concat(['src/anysdk/jsb_anysdk.js', 'src/anysdk/jsb_anysdk_constants.js']);
    }

    var option = {
        id: 'GameCanvas',
        scenes: settings.scenes,
        debugMode: settings.debug ? cc.debug.DebugMode.INFO : cc.debug.DebugMode.ERROR,
        showFPS: settings.debug,
        frameRate: 60,
        jsList: jsList,
        groupList: settings.groupList,
        collisionMatrix: settings.collisionMatrix,
        renderMode: 0
    }
    
    // init assets
    cc.AssetLibrary.init({
        libraryPath: 'res/import',
        rawAssetsBase: 'res/raw-',
        rawAssets: settings.rawAssets,
        packedAssets: settings.packedAssets,
        md5AssetsMap: settings.md5AssetsMap,
        subpackages: settings.subpackages
    });
    cc.game.run(option, onStart);
};

if (jsb) {
    var hotUpdateSearchPaths = localStorage.getItem('HotUpdateSearchPaths');
    if (hotUpdateSearchPaths) {
        jsb.fileUtils.setSearchPaths(JSON.parse(hotUpdateSearchPaths)); 
    }
}

require('src/settings.js');
require('src/cocos2d-jsb.js');
// require('jsb-adapter/engine/index.js');
require('jsb-adapter/jsb-engine.js');

window.boot();