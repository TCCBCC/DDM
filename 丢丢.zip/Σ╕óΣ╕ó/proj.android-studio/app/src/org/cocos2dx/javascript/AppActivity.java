/****************************************************************************
 Copyright (c) 2015-2016 Chukong Technologies Inc.
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.

 http://www.cocos2d-x.org

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/
package org.cocos2dx.javascript;

        import org.cocos2dx.lib.Cocos2dxActivity;
        import org.cocos2dx.lib.Cocos2dxGLSurfaceView;

        import android.content.Context;
        import android.content.pm.ActivityInfo;
        import android.content.pm.PackageInfo;
        import android.content.pm.PackageManager;

        import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.net.Uri;
        import android.net.wifi.WifiInfo;
        import android.net.wifi.WifiManager;
        import android.os.Build;
        import android.os.Bundle;

        import android.content.Intent;
        import android.content.res.Configuration;


        import android.text.TextUtils;
        import android.util.Log;
        import android.view.WindowManager;
        import android.widget.ImageView;


        import com.baidu.mobstat.StatService;

        import jjxs.ljHX.ewer.UpLoadImg;
        import jjxs.ljHX.ewer.umeng.UmengManager;



        import java.io.FileNotFoundException;

        import java.io.FileReader;

        import java.io.InputStreamReader;
        import java.io.LineNumberReader;
        import java.io.Reader;

        import java.net.NetworkInterface;

        import java.util.Collections;

        import java.util.List;

        import java.util.UUID;

        import cn.jpush.android.api.JPushInterface;
//import cz.msebera.android.httpclient.util.TextUtils;
        import io.openinstall.cocos2dx.OpenInstallActivity;





public class AppActivity extends OpenInstallActivity {
    private static Cocos2dxActivity sContext = null;
    private static Cocos2dxActivity sgsActivity = null;
    private static Cocos2dxActivity mActivity = null;


    public static final int TAKE_PHOTO = 1;
    public static final int SELECT_PHOTO = 2;
    private ImageView imageview;
    private Uri imageUri;



    public static final String ERROR_MAC_STR = "02:00:00:00:00:00";
    private static WifiManager mWifiManager = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        添加
        sContext = this;
        sgsActivity = this;
        mActivity = this;
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
//        添加
        // Workaround in https://stackoverflow.com/questions/16283079/re-launch-of-activity-on-home-button-but-only-the-first-time/16447508
        if (!isTaskRoot()) {
            // Android launched another instance of the root activity into an existing task
            //  so just quietly finish and go away, dropping the user back into the activity
            //  at the top of the stack (ie: the last state of this task)
            // Don't need to finish it again since it's finished in super.onCreate .
            return;
        }
        // DO OTHER INITIALIZATION BELOW
        SDKWrapper.getInstance().init(this);
//        添加
        UmengManager.init(this);
        UmengManager.setWeixinPlatForm("","");
        SDKWrapper.getInstance().init(this);
        JPushInterface.setDebugMode(false);//测试版为true
        JPushInterface.init(this);
        String registrationId = JPushInterface.getRegistrationID(this);
        Log.e("1099", "run:--------->registrationId： "+registrationId );
        UpLoadImg.init(this);
        StatService.start(this);

//        添加
    }

    @Override
    public Cocos2dxGLSurfaceView onCreateView() {
        Cocos2dxGLSurfaceView glSurfaceView = new Cocos2dxGLSurfaceView(this);
        // TestCpp should create stencil buffer
        glSurfaceView.setEGLConfigChooser(5, 6, 5, 0, 16, 8);
        SDKWrapper.getInstance().setGLSurfaceView(glSurfaceView, this);

        return glSurfaceView;
    }

    @Override
    protected void onResume() {
        super.onResume();
        SDKWrapper.getInstance().onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
        SDKWrapper.getInstance().onPause();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SDKWrapper.getInstance().onDestroy();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        SDKWrapper.getInstance().onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {

            case TAKE_PHOTO :
                if (resultCode == RESULT_OK) {
                    try {
                        Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
                        imageview.setImageBitmap(bitmap);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }
                break;
            case SELECT_PHOTO :
                if (resultCode == RESULT_OK) {
                    //判断手机系统版本号
                    if (Build.VERSION.SDK_INT > 19) {
                        //4.4及以上系统使用这个方法处理图片
                        UpLoadImg.handleImgeOnKitKat(data);
                    }else {
                        UpLoadImg.handleImageBeforeKitKat(data);
                    }
                }
                break;
            default:
                break;
        }


    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        SDKWrapper.getInstance().onNewIntent(intent);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        SDKWrapper.getInstance().onRestart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        SDKWrapper.getInstance().onStop();
    }

    @Override
    public void onBackPressed() {
        SDKWrapper.getInstance().onBackPressed();
        super.onBackPressed();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        SDKWrapper.getInstance().onConfigurationChanged(newConfig);
        super.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        SDKWrapper.getInstance().onRestoreInstanceState(savedInstanceState);
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        SDKWrapper.getInstance().onSaveInstanceState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onStart() {
        SDKWrapper.getInstance().onStart();
        super.onStart();
    }
    //    添加方法
    public static boolean copyToClipboard(final  String text){
        final Context context = sgsActivity;//参数要加final关键字，否则内部类不能访问
        try{
            Runnable runnable = new Runnable() {
                public void run() {
                    android.content.ClipboardManager clipboard = (android.content.ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                    android.content.ClipData clip = android.content.ClipData.newPlainText("Copied Text", text);
                    clipboard.setPrimaryClip(clip);
                }


            };
            //getSystemService运行所在线程必须执行过Looper.prepare()
            //否则会出现Can't create handler inside thread that has not called Looper.prepare()
            sgsActivity.runOnUiThread(runnable);

        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }
    public static String getPseudoUniqueId() {
        String serial = null;

        String m_szDevIDShort = "35" +
                Build.BOARD.length() % 10 + Build.BRAND.length() % 10 +

                Build.CPU_ABI.length() % 10 + Build.DEVICE.length() % 10 +

                Build.DISPLAY.length() % 10 + Build.HOST.length() % 10 +

                Build.ID.length() % 10 + Build.MANUFACTURER.length() % 10 +

                Build.MODEL.length() % 10 + Build.PRODUCT.length() % 10 +

                Build.TAGS.length() % 10 + Build.TYPE.length() % 10 +

                Build.USER.length() % 10; //13 位

        try {
            serial = android.os.Build.class.getField("SERIAL").get(null).toString();
            //API>=9 使用serial号
            return new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString();
        } catch (Exception exception) {
            //serial需要一个初始化
            serial = "serial"; // 随便一个初始化
        }
        //使用硬件信息拼凑出来的15位号码
        return new UUID(m_szDevIDShort.hashCode(), serial.hashCode()).toString();
    }
    public static void openURL(String url)
    {
        try {
            Uri uri = Uri.parse(url);
            Intent it = new Intent(Intent.ACTION_VIEW, uri);
            sContext.startActivity(it);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
    public static String getAndroidId(){ // 获取唯一设备号
        String mac = getMobileMAC();
        if(mac.equals(ERROR_MAC_STR)){
            return getPseudoUniqueId();
        }else{
            System.out.println("获取mac地址成功");
            Log.e("mac", "get android low version mac errorfdfdf:");
            System.out.println("Hello World." + mac);
            return  mac;
        }
    }
    public static String getVersionName() {
        Context context = sgsActivity;
        //获取包管理器
        PackageManager pm = context.getPackageManager();
        //获取包信息
        try {
            PackageInfo packageInfo = pm.getPackageInfo(context.getPackageName(), 0);
            //返回版本号
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return null;

    }
    private static WifiManager getInstant() {
//        final Context context = sgsActivity;//参数要加final关键字，否则内部类不能访问
        if (mWifiManager == null) {
            mWifiManager = (WifiManager)  mActivity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        }
        return mWifiManager;
    }
    public static String getMobileMAC() {

        mWifiManager = getInstant();

        // 如果当前设备系统大于等于6.0 使用下面的方法
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return getAndroidHighVersionMac();
        } else { // 当前设备在6.0以下
            return getAndroidLowVersionMac(mWifiManager);
        }
    }
    public static String getAndroidHighVersionMac() {
        String str = "";
        String macSerial = "";
        try {
            // 由于Android底层基于Linux系统 可以根据shell获取
            Process pp = Runtime.getRuntime().exec(
                    "cat /sys/class/net/wlan0/address ");
            InputStreamReader ir = new InputStreamReader(pp.getInputStream());
            LineNumberReader input = new LineNumberReader(ir);
            for (; null != str; ) {
                str = input.readLine();
                if (str != null) {
                    macSerial = str.trim();// 去空格
                    break;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        if (macSerial == null || "".equals(macSerial)) {
            try {
                return loadFileAsString("/sys/class/net/eth0/address")
                        .toUpperCase().substring(0, 17);
            } catch (Exception e) {
                e.printStackTrace();
                macSerial = getAndroidVersion7MAC();
            }
        }
        return macSerial;
    }
    private static String getAndroidLowVersionMac(WifiManager wifiManager) {
        try {
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            String mac = wifiInfo.getMacAddress();
            if (TextUtils.isEmpty(mac)) {
                return ERROR_MAC_STR;
            } else {
                return mac;
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("mac", "get android low version mac error:" + e.getMessage());
            return ERROR_MAC_STR;
        }
    }
    public static String loadFileAsString(String fileName) throws Exception {
        FileReader reader = new FileReader(fileName);
        String text = loadReaderAsString(reader);
        reader.close();
        return text;
    }
    public static String getAndroidVersion7MAC() {
        try {
//            List<NetworkInterface> all =  Collections.list(NetworkInterface.getNetworkInterfaces());
            List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
//            List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif : all) {
                if (!nif.getName().equalsIgnoreCase("wlan0")) continue;
                byte[] macBytes = nif.getHardwareAddress();
                if (macBytes == null) {
                    return "";
                }
                StringBuilder res1 = new StringBuilder();
                for (byte b : macBytes) {
                    res1.append(String.format("%02X:", b));
                }
                if (res1.length() > 0) {
                    res1.deleteCharAt(res1.length() - 1);
                }
                return res1.toString();
            }
        } catch (Exception e) {
            Log.e("mac", "get android version 7.0 mac error:" + e.getMessage());
        }
        return ERROR_MAC_STR;
    }
    public static String loadReaderAsString(Reader reader) throws Exception {
        StringBuilder builder = new StringBuilder();
        char[] buffer = new char[4096];
        int readLength = reader.read(buffer);
        while (readLength >= 0) {
            builder.append(buffer, 0, readLength);
            readLength = reader.read(buffer);
        }
        return builder.toString();
    }
    public static void clickTestMD(String url){
        try {
            StatService.onEventStart(sContext,url,"123456");
            StatService.onEvent(sContext,url,"123456",1);
            Log.e("埋点","get android version 7.0 mac error:"+ url);
        }catch (Exception e){

        }
    }
    public static void setOrientation(int orientation) {
        Log.i("MyOrientationDetector ", "onOrientationChanged:" + orientation);
        if (orientation == 1) {
            sContext.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            sContext.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else if (orientation == 2) {
            sContext.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            sContext.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        } else if (orientation == 3) {
            sContext.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
            sContext.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
        }
//        return 0;
    }
    public static String myGetJPushID() {

//        final Context context = sgsActivity;//参数要加final关键字，否则内部类不能访问
        String registrationId = JPushInterface.getRegistrationID(sgsActivity);
        return registrationId;
    }

    public static void myBindPushID(String uid) {

        final Context context = sgsActivity;//参数要加final关键字，否则内部类不能访
        String registrationId = JPushInterface.getRegistrationID(context);


        JPushInterface.setAlias(context,0,uid);
    }

    public static void saveTextureToLocal(String pngPath,String ImgName){
        UpLoadImg.saveTextureToLocalFun(pngPath,ImgName);
    }


    public static void getLocalImg(String url) {

        String Url = url;
        UpLoadImg.getAblameImg( Url );

    }








//    添加方法
}
