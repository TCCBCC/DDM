package jjxs.ljHX.ewer.umeng;



import android.graphics.Bitmap;

import android.os.Environment;


import com.umeng.socialize.Config;
import com.umeng.socialize.PlatformConfig;
import com.umeng.socialize.ShareAction;
import com.umeng.socialize.UMAuthListener;
import com.umeng.socialize.UMShareAPI;
import com.umeng.socialize.UMShareListener;
import com.umeng.socialize.bean.SHARE_MEDIA;
import com.umeng.socialize.media.UMImage;
import com.umeng.socialize.media.UMWeb;


import org.cocos2dx.javascript.AppActivity;
import org.cocos2dx.lib.Cocos2dxJavascriptJavaBridge;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import jjxs.ljHX.ewer.ImgSave;

import jjxs.ljHX.ewer.ShareUtils;

/**
 * Created by litengfei on 16/12/5.
 */


//cocos里重载UmengManager的一些回调方法即可

public class UmengManager {
    public static AppActivity g_Activity = null;
    public static void init(AppActivity activity) {
        g_Activity = activity;
        UMShareAPI.get(g_Activity);
        Config.isJumptoAppStore = true;
    }

    public static void setWeixinPlatForm(String appID,String screatID){
        PlatformConfig.setWeixin(appID, screatID);
    }

    //判断微信是否登录
    public static boolean isWeixinInstalled(String placeHolder){
        return true;
    }

    public static void weixinLogin(String placeHolder) {
        g_Activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                UMShareAPI mShareAPI = UMShareAPI.get(g_Activity);
                //mShareAPI.doOauthVerify(g_Activity, SHARE_MEDIA.WEIXIN, umAuthListener);
                mShareAPI.getPlatformInfo(g_Activity, SHARE_MEDIA.WEIXIN, platformListener);
            }
        });
    }

    public  static void weixinFrendShareImage(final String localImageUrl){
        g_Activity.runOnGLThread(new Runnable() {
            @Override
            public void run() {
                final String finalimageUrl = localImageUrl;
                UMImage image = new UMImage(g_Activity, finalimageUrl);//网络图片
                new ShareAction(g_Activity).setPlatform(SHARE_MEDIA.WEIXIN)
                        .withMedia(image)
                        .setCallback(umShareListener)
                        .share();
            }
        });
    }


    /**
     * 分享微信好友
     */
    private static void sharWx(String linkUrl){
//        UMImage image = ShareUtils.thumbImg(g_Activity,ShareUtils.getImg(g_Activity.getBaseContext(),linkUrl));
        final Bitmap bitmap = ShareUtils.getImg(g_Activity.getBaseContext(),linkUrl);
        UMImage image = ShareUtils.thumbImg(g_Activity,bitmap);
        new ShareAction(g_Activity)
                .setPlatform(SHARE_MEDIA.WEIXIN)//传入平台
                .withMedia(image)
                .setCallback(umShareListener)//回调监听器
                .share();
        //开启线程保存图片并刷新相册
        new Thread(new Runnable() {
            @Override
            public void run() {
                String filename = System.currentTimeMillis()+".jpg";
                // String path = g_Activity.getBaseContext().getExternalFilesDir("photo").getAbsolutePath();//android/data/包名/file/photo
                String path = Environment.getExternalStorageDirectory()+ File.separator+ "fast"+File.separator+"photo"+File.separator;
                ImgSave.saveTextureToLocal(g_Activity.getBaseContext(),bitmap,path,filename);
            }
        }).start();

    }

    /**
     * 分享朋友圈
     */
    private static void sharFriend(String linkUrl){
        final Bitmap bitmap = ShareUtils.getImg(g_Activity.getBaseContext(),linkUrl);
        UMImage image = ShareUtils.thumbImg(g_Activity,bitmap);



        new ShareAction(g_Activity)
                .setPlatform(SHARE_MEDIA.WEIXIN_CIRCLE)//传入平台
                .withMedia(image)
                .setCallback(umShareListener)//回调监听器
                .share();
        //开启线程保存图片并刷新相册
        new Thread(new Runnable() {
            @Override
            public void run() {
                String filename = System.currentTimeMillis()+".jpg";
                // String path = g_Activity.getBaseContext().getExternalFilesDir("photo").getAbsolutePath();//android/data/包名/file/photo
                String path = Environment.getExternalStorageDirectory()+ File.separator+ "fast"+File.separator+"photo"+File.separator;
                ImgSave.saveTextureToLocal(g_Activity.getBaseContext(),bitmap,path,filename);
            }
        }).start();
    }

    public static void weixinShare(final String title, String desc, String imageUrl, String webUrl){//微信分享

        final String finalTitle = title;
        final String finaldesc = desc;
        final String finalimageUrl = imageUrl;
        final String finalwebUrl = webUrl;

//        sharFriend(finalwebUrl);
        g_Activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                UMImage thumb = new UMImage(g_Activity, finalimageUrl);//网络图片
                thumb.setDescription(finaldesc);


                UMWeb web = new UMWeb(finalwebUrl);//网络图片
                web.setThumb(thumb);
                web.setTitle(finalTitle);
                web.setDescription(finaldesc);


                new ShareAction(g_Activity).setPlatform(SHARE_MEDIA.WEIXIN_CIRCLE)
                        .withMedia(web)
                        .setCallback(umShareListener)
                        .share();
            }
        });
    }

    public static void weixinFriendShare(String title,String desc,String imageUrl,String webUrl){//微信好友分享
        final String finalTitle = title;
        final String finaldesc = desc;
        final String finalimageUrl = imageUrl;
        final String finalwebUrl = webUrl;

//        sharWx(finalwebUrl);
        g_Activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                UMImage thumb = new UMImage(g_Activity, finalimageUrl);//网络图片
                thumb.setDescription(finaldesc);


                UMWeb web = new UMWeb(finalwebUrl);//网络图片
                web.setThumb(thumb);
                web.setTitle(finalTitle);
                web.setDescription(finaldesc);



                new ShareAction(g_Activity).setPlatform(SHARE_MEDIA.WEIXIN)
                        .withMedia(web)
                        .setCallback(umShareListener)
                        .share();
            }
        });
    }


    public static void notifyLoginSuccess(Map<String, String> info) {
        int isOK = info == null?0:1;
        if(isOK == 0){
            info = new HashMap();
        }
        final String successMsg = String.format("Global.UmengNative.weixinLoginSuccess(%s,\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\');",isOK,info.get("openid"), info.get("unionid"),
                info.get("access_token"), info.get("refresh_token"), info.get("expires_in"), info.get("screen_name"), info.get("city"), info.get("prvinice"),
                info.get("country"), info.get("gender"), info.get("profile_image_url"));

        g_Activity.runOnGLThread(new Runnable() {
            @Override
            public void run() {
                Cocos2dxJavascriptJavaBridge.evalString(successMsg);
            }
        });
    }

    public static void notifyShareFinish(int isOK){
        final String successMsg = String.format("Global.UmengNative.weixinShareSuccess(%d);",isOK);
        g_Activity.runOnGLThread(new Runnable() {
            @Override
            public void run() {
                Cocos2dxJavascriptJavaBridge.evalString(successMsg);
            }
        });
    }

    private static UMShareListener umShareListener = new UMShareListener() {
        @Override
        public void onStart(SHARE_MEDIA share_media) {

        }

        @Override
        public void onResult(SHARE_MEDIA platform) {
            //Log.d("plat","platform"+platform);

            //Toast.makeText(g_Activity, platform + " 分享成功啦", Toast.LENGTH_SHORT).show();
            notifyShareFinish(1);

        }

        @Override
        public void onError(SHARE_MEDIA platform, Throwable t) {
            //Toast.makeText(g_Activity,platform + " 分享失败啦", Toast.LENGTH_SHORT).show();
            if(t!=null){
                //Log.d("throw","throw:"+t.getMessage());
            }
            //notifyShareFinish(0);
        }

        @Override
        public void onCancel(SHARE_MEDIA platform) {
            //Toast.makeText(g_Activity,platform + " 分享取消了", Toast.LENGTH_SHORT).show();
            //notifyShareFinish(0);
        }
    };

    private static UMAuthListener platformListener = new UMAuthListener() {
        @Override
        public void onStart(SHARE_MEDIA share_media) {

        }

        @Override
        public void onComplete(SHARE_MEDIA platform, int action, Map<String, String> data) {
            //Toast.makeText(g_Activity, "getInfo succeed", Toast.LENGTH_SHORT).show();
            notifyLoginSuccess(data);
        }

        @Override
        public void onError(SHARE_MEDIA platform, int action, Throwable t) {
            //Toast.makeText( g_Activity, "Authorize fail", Toast.LENGTH_SHORT).show();
            notifyLoginSuccess(null);
        }

        @Override
        public void onCancel(SHARE_MEDIA platform, int action) {
            //Toast.makeText( g_Activity, "Authorize cancel", Toast.LENGTH_SHORT).show();
            notifyLoginSuccess(null);
        }
    };
}
