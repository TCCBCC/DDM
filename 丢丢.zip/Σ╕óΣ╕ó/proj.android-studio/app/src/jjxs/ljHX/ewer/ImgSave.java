package jjxs.ljHX.ewer;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;

import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;

import android.support.v4.app.ActivityCompat;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;



public class ImgSave {
    // 获取 路径中的图片 保存到本地
    public static void saveTextureToLocal(final Context mcontext, Bitmap bitmap, String pngPath, String ImgName) {


        int permission = ActivityCompat.checkSelfPermission(mcontext, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        try {
            if (permission != PackageManager.PERMISSION_GRANTED) {
                // We don't have permission so prompt the user
                //ActivityCompat.requestPermissions(app, PERMISSIONS_STORAGR,REQUEST_EXTERNAL_STORAGE);
                ExampleUtil.showToast("保存图片失败，请确定相册权限是否开启", mcontext);
                return;
            }


            //判断路径是否存在，不存在就创建
            if(!new File(pngPath).exists()){
                new File(pngPath).mkdirs();
            }
            File file = new File(pngPath,ImgName);//图片保存文件夹路径
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
            //释放bitmap，防止占内存
            if(bitmap!= null){
                bitmap.recycle();
            }

//            Log.d("保存成功", pngPath);
            ExampleUtil.showToast("保存图片成功", mcontext);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                MediaScannerConnection.scanFile(mcontext, new String[]{file.getAbsolutePath()}, null,
                        new MediaScannerConnection.OnScanCompletedListener() {
                            public void onScanCompleted(String path, Uri uri) {
                                Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                                mediaScanIntent.setData(uri);
                                mcontext.sendBroadcast(mediaScanIntent);
                            }
                        });
            } else {
                String relationDir = file.getParent();
                File file1 = new File(relationDir);
                mcontext.sendBroadcast(new Intent(Intent.ACTION_MEDIA_MOUNTED, Uri.fromFile(file1.getAbsoluteFile())));
            }
        } catch (FileNotFoundException e) {
//            Log.d("保存错误1", e.toString());
            e.printStackTrace();
            ExampleUtil.showToast("保存图片失败", mcontext);

            e.printStackTrace();
        } catch (IOException e) {
//            Log.d("保存错误2", e.toString());
            e.printStackTrace();
            ExampleUtil.showToast("保存图片失败", mcontext);

            e.printStackTrace();
        }



        // 其次把文件插入到系统图库
//        try {
//            MediaStore.Images.Media.insertImage(AppActivity.getContext().getApplicationContext().getContentResolver(),
//                    file.getAbsolutePath(), fileName, null);
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//        // 最后通知图库更新
//        AppActivity.getContext().getApplicationContext().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse(file.getAbsolutePath())));
    }

}
