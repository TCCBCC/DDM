package jjxs.ljHX.ewer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;



import com.umeng.socialize.media.UMImage;

//import jjxs.ljHX.ewer.R;



public   class ShareUtils {

    public  static  Bitmap getImg(Context context,String sharelink){
        Bitmap bg = BitmapFactory.decodeResource(context.getResources(), R.mipmap.bg_share_with_image_money);
        Bitmap qr = jjxs.ljHX.ewer.QrUtils.generateQRCode(sharelink,bg.getWidth()/2,bg.getWidth()/2);//生成二维码

        Bitmap result = Bitmap.createBitmap(bg.getWidth(), bg.getHeight(), Bitmap.Config.RGB_565);// 创建一个新的和SRC长度宽度一样的位图
        Canvas cv = new Canvas(result);
        cv.drawBitmap(bg, 0, 0, null);
        cv.drawBitmap(qr, (bg.getWidth()-qr.getWidth())/2, (bg.getHeight()/4)*2, null);


        cv.save();
        cv.restore();
        return  result;
    }

    /**
     * 图片太大生成缩略图
     * @param activity
     * @param bitmap
     * @return
     */
    public static UMImage thumbImg(Activity activity,Bitmap bitmap){
        UMImage image = new UMImage(activity, bitmap);//资源文件
        image.setThumb(image);
        image.compressStyle = UMImage.CompressStyle.SCALE;
        return  image;
    }



}
