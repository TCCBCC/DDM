package jjxs.ljHX.ewer;

import android.Manifest;
import android.content.ContentUris;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Base64;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.gson.Gson;

import com.umeng.socialize.Config;



import org.cocos2dx.javascript.AppActivity;
import org.cocos2dx.lib.Cocos2dxJavascriptJavaBridge;
//import org.jetbrains.annotations.NotNull;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

//import cz.msebera.android.httpclient.HttpResponse;
//import cz.msebera.android.httpclient.NameValuePair;
//import cz.msebera.android.httpclient.ParseException;
//import cz.msebera.android.httpclient.client.ClientProtocolException;
//import cz.msebera.android.httpclient.client.HttpClient;
//import cz.msebera.android.httpclient.client.entity.UrlEncodedFormEntity;
//import cz.msebera.android.httpclient.client.methods.HttpPost;
//import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
//import cz.msebera.android.httpclient.message.BasicNameValuePair;
//import cz.msebera.android.httpclient.protocol.HTTP;
//import cz.msebera.android.httpclient.util.EntityUtils;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class UpLoadImg{
    public static AppActivity sgsActivity = null;
    public static final int TAKE_PHOTO = 1;
    public static final int SELECT_PHOTO = 2;
    public static  String upLoadImgUrl = null;
    private ImageView imageview;
    private Uri imageUri;
    public static void init(AppActivity activity) {
        sgsActivity = activity;

        Config.isJumptoAppStore = true;
    }


    public static void getAblameImg(String url) {
        if (ContextCompat.checkSelfPermission(sgsActivity, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(sgsActivity,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        }else {
            upLoadImgUrl = url;
            openAlbum( );
        };
    }
    public static void openAlbum() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("image/*");
        sgsActivity.startActivityForResult(intent,SELECT_PHOTO);
    }
    /**
     *4.4以下系统处理图片的方法
     * */
    public static void handleImageBeforeKitKat(Intent data) {
        Uri uri = data.getData();
        String imagePath = getImagePath(uri,null);
        displayImage(imagePath);
    }
    public static void handleImgeOnKitKat(Intent data) {
        String imagePath = null;
        Uri uri = data.getData();
        if (DocumentsContract.isDocumentUri(sgsActivity,uri)) {
            //如果是document类型的uri，则通过document id处理
            String docId = DocumentsContract.getDocumentId(uri);
            if ("com.android.providers.media.documents".equals(uri.getAuthority())) {
                //解析出数字格式的id
                String id = docId.split(":")[1];
                String selection = MediaStore.Images.Media._ID + "=" + id;
                imagePath = getImagePath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,selection);
            }else if ("com.android.providers.downloads.documents".equals(uri.getAuthority())) {
                Uri contentUri = ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"),Long.valueOf(docId));
                imagePath = getImagePath(contentUri,null);
            }else if ("content".equalsIgnoreCase(uri.getScheme())) {
                //如果是content类型的uri，则使用普通方式处理
                imagePath = getImagePath(uri,null);
            }else if ("file".equalsIgnoreCase(uri.getScheme())) {
                //如果是file类型的uri，直接获取图片路径即可
                imagePath = uri.getPath();
            }
            //根据图片路径显示图片
            displayImage(imagePath);
        }
    }
    /**
     * 根据图片路径显示图片的方法
     * */
    public static void displayImage(String imagePath) {

        if (imagePath != null) {
//            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
            Log.i("upLoadImgU",upLoadImgUrl);
            Log.i("upLoadImgU","upLoadImgUrlupLoadImgUrlupLoadImgUrl");
//            uploadImg("http://192.168.50.122:8056/api/file/upload", imagePath);
            uploadImg(upLoadImgUrl, imagePath);
//            bitmapToBase64(bitmap);

        }else {
            Toast.makeText(sgsActivity,"获取图片失败",Toast.LENGTH_SHORT).show();
        }
    }
    public static String getImagePath(Uri uri,String selection) {
        String path = null;
        Cursor cursor = sgsActivity.getContentResolver().query(uri,null,selection,null,null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                path = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
            }
            cursor.close();
        }
        return path;
    }
    private static void  bitmapToBase64(Bitmap bitmap) {
        String result = null;
        ByteArrayOutputStream baos = null;
        try {
            if (bitmap != null) {
                baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 40, baos);

                baos.flush();
                baos.close();

                byte[] bitmapBytes = baos.toByteArray();
                result = Base64.encodeToString(bitmapBytes, Base64.DEFAULT);

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (baos != null) {
                    baos.flush();
                    baos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
//    public static void setImgByStr(final String url,final String imgStr,final String imgName){
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                Map<String,Object> params = new HashMap<String, Object>();
//                params.put("imgStr", imgStr);
//                params.put("imgName", imgName);
//                getValues(params, url);
//            }
//        }).start() ;
//
//    }

//    public static Object getValues(Map<String, Object> params, String url) {
//        String token = "";
//        HttpResponse response = post(params, url);
//        System.out.println(response);
//        if (response != null) {
//            try {
//                token = EntityUtils.toString(response.getEntity());
//                response.removeHeaders("operator");
//            } catch (ParseException e) {
//                e.printStackTrace();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        return token;
//    }
//    public static HttpResponse post(Map<String, Object> params, String url) {
//
//        HttpClient client = new DefaultHttpClient();
//        HttpPost httpPost = new HttpPost(url);
//        httpPost.addHeader("charset", HTTP.UTF_8);
//        httpPost.setHeader("Content-Type",
//                "application/x-www-form-urlencoded; charset=utf-8");
//        HttpResponse response = null;
//        if (params != null && params.size() > 0) {
//            List<NameValuePair> nameValuepairs = new ArrayList<NameValuePair>();
//            for (String key : params.keySet()) {
//                nameValuepairs.add(new BasicNameValuePair(key, (String) params
//                        .get(key)));
//            }
//            try {
//                httpPost.setEntity(new UrlEncodedFormEntity(nameValuepairs,
//                        HTTP.UTF_8));
//                response = client.execute(httpPost);
//                String res = new Gson().toJson(response);
//            } catch (UnsupportedEncodingException e) {
//                e.printStackTrace();
//            } catch (ClientProtocolException e) {
//                e.printStackTrace();
//            } catch (IOException e) {
//                e.printStackTrace();
//            } catch (RuntimeException e) {
//                e.printStackTrace();
//            }
//        } else {
//            try {
//                response = client.execute(httpPost);
//            } catch (ClientProtocolException e) {
//                e.printStackTrace();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//
//        return response;
//
//    }
    /**
     * 上传图片多张(使用ok)
     *
     * @param url
     * @return 新图片的路径
     * @throws IOException
     * @throws
     */
    public static void uploadImg(String url, final String imagePath) {
//         String baseResponse = "";
//        BaseResponse baseResponse =null;
        OkHttpClient okHttpClient = new OkHttpClient();
        try {
            //上传文件类型
            //表单形式上传
            MultipartBody.Builder builder = new MultipartBody.Builder().setType(MultipartBody.FORM);
            //添加上传文件
           /* for (String path  : pathList) {
                File file = new File(BitmapUtil.compressImage(path));
                File file = new File(path);
                RequestBody image = RequestBody.create(UMediaObject.MediaType.parse("image/*"), file);
                builder.addFormDataPart("file",url, image);

            }
            RequestBody requestBody = builder.build();*/
            //单个上传
//           Log.d("imagePath", imagePath);
            File file = new File(imagePath);
            RequestBody image = RequestBody.create(MediaType.parse("image/*"), file);
           final RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("file", imagePath, image)
//                    .addFormDataPart( "dfd",imagePath)
//                    .addFormDataPart()
                    .build();
            //发起请求
            Request request = new Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build();

             okHttpClient.newBuilder().readTimeout(20000, TimeUnit.MILLISECONDS).build().newCall(request).enqueue(new Callback() {
                 @Override
                 public void onFailure( Call call,  IOException e) {
                     Log.e("Ok上传图片","失败回调: call="+call==null?"":call.toString());
                     e.printStackTrace();

                 }

                 @Override
                 public void onResponse( Call call,  Response response) throws IOException {
                   //  Log.d("Ok上传图片","成功回调 \nmessage="+response.message()+"\n数据="+response.body().string()+"\nhttp状态码="+response.code() +"\nheader"+response.headers().toString());
//                     Log.e("Ok上传图片","2333333 ");

                     if(response.code() == 200 ) {

                             String imagePath = "";
                             try {
                                 JSONObject jsonObject = new JSONObject(response.body().string());
                                 if(jsonObject!=null){
                                     if(jsonObject.getString("data")!=null){
                                         imagePath =jsonObject.getString("data");// 图片路径
//                                         Log.e("Ok上传图片", imagePath);
                                     }
                                 }
                             }catch (Exception e){
                                 imagePath = "";
                             }


                         final String successMsg = String.format("Global.CCHelper.getImgFile(\"%s\");",imagePath);
                         sgsActivity.runOnGLThread(new Runnable() {
                             @Override
                             public void run() {
                                 Cocos2dxJavascriptJavaBridge.evalString(successMsg);
                             }
                         });

                     }
                 }
             });


        } catch (Exception e) {
           e.printStackTrace();
        }

    }
    public static boolean getStorePermission() {
//        final Context context = sgsActivity;

        int permission = ActivityCompat.checkSelfPermission(sgsActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            //ActivityCompat.requestPermissions(app, PERMISSIONS_STORAGR,REQUEST_EXTERNAL_STORAGE);
//            ExampleUtil.showToast("保存图片失败，请确定相册权限是否开启", context);
            return false;
        } else {
            return true;
        }
    }
    // 获取 路径中的图片 保存到本地
    public static void saveTextureToLocalFun( String pngPath,String ImgName) {


        int permission = ActivityCompat.checkSelfPermission(sgsActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            //ActivityCompat.requestPermissions(app, PERMISSIONS_STORAGR,REQUEST_EXTERNAL_STORAGE);
            ExampleUtil.showToast("保存图片失败，请确定相册权限是否开启", sgsActivity);
            return;
        } else {

        }




        //从路径中读取 照片
        Bitmap bmp = BitmapFactory.decodeFile(pngPath);

        // fileName ==textureName  尽量和JS保存的一致
        String fileName = ImgName;
        File file = new File(pngPath);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.flush();
            fos.close();
            ExampleUtil.showToast("保存图片成功", sgsActivity);
        } catch (FileNotFoundException e) {

            ExampleUtil.showToast("保存图片失败", sgsActivity);

            e.printStackTrace();
        } catch (IOException e) {

            ExampleUtil.showToast("保存图片失败", sgsActivity);

            e.printStackTrace();
        }

        // 其次把文件插入到系统图库
        try {
            MediaStore.Images.Media.insertImage(AppActivity.getContext().getApplicationContext().getContentResolver(),
                    file.getAbsolutePath(), fileName, null);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        // 最后通知图库更新
        AppActivity.getContext().getApplicationContext().sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse(file.getAbsolutePath())));
    }
}
